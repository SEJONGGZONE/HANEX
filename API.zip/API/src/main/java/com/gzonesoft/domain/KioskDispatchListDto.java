package com.gzonesoft.domain;

public class KioskDispatchListDto {
    public String SHNUMBER;
    public String SHN_SEQ;
    public String LOADING_REQUEST_ID;
    public String REQUEST_DATE;
    public String REQUEST_TIME;
    public String SOURCE_CD;
    public String SOURCE_NM;
    public String CUST_CD;
    public String CUST_NM;
    public String CUST_ADDRESS;
    public String ITEM_NM;
    public String SHIPMENT_VOLUME;
    public String SHIP_METHOD;
    public String CARD_YN;
    public String CARD_NO;
    public String SEAL_YN;
    public String SEAL_NO;
    public String VEHICLE_CD;
    public String LOADING_KEY;
}
