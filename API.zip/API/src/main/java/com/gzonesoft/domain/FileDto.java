package com.gzonesoft.domain;

public class FileDto {
	public String fileName = "";
	public String fileFormat = "";
	public String fileSize = "";
	public String fileKind = "";
	public String filePath1 = "";
	public String filePath2 = "";
	public String encryptKey = "";
	public String fileCreatedTime = "";
	public String fileNo = "";
	// 출하전표관련 추가
	public String signFileCd = "";
	public String signFilePath = "";
	public String invoiceFileCd = "";
	public String invoiceFilePath = "";

}
