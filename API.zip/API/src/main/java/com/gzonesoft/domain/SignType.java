package com.gzonesoft.domain;

/**
 * 서명유형
 */
public class SignType {
    public static final String _기사서명 = "10";
    public static final String _고객사서명 = "20";


}
