package com.gzonesoft.security;

public interface ApiKeyService {
	boolean validateApiKey(String apiKey);
}
