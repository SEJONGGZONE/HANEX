package com.gzonesoft.controller;

import com.gzonesoft.domain.KioskDispatchListDto;
import com.gzonesoft.service.EAIService;
import com.gzonesoft.service.KioskService;
import com.gzonesoft.utils.SysUtils;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.web.bind.annotation.*;

import java.security.NoSuchAlgorithmException;
import java.util.*;

/**
 * http://localhost:9032/swagger-ui.html
 * @author ships
 *
 */
@RequestMapping("/api")
@RestController
public class KioskController {
	@Autowired private KioskService kioskService;
	@Autowired private EAIService eaiService;

	/**
	 {

	 }
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="앱체크")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_IP\":\"172.16.62.79\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/appCheckKiosk")
	public @ResponseBody Map<String, Object> appCheckKiosk(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return kioskService.appCheckKiosk(json_body);
	}

	/**
	 *
	 * @param api_key
	 * @return
	 */
	@ApiOperation(value="앱 업데이트 파일 목록")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
	})
	@CrossOrigin("*")
	@PostMapping(value="/getUpdateFiles")
	public @ResponseBody Map<String, Object> getUpdateFiles(@RequestHeader String api_key){
		LinkedHashMap<String, Object> param = new LinkedHashMap<String, Object>();
		return kioskService.getUpdateFiles(param);
	}

	/**
	 {
	 }
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="[작성중] 최종작업상태조회(공지사항포함)")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_TERMINAL_CODE\":\"1000\",\r\n" +
							"        	\"I_KIOSK_NO\":\"1002\",\r\n" +
							"        	\"I_DRV_CD\":\"\",\r\n" +
							"        	\"I_VEHICLE_CD\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/lastWorkSel")
	public @ResponseBody Map<String, Object> lastWorkSel(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return kioskService.lastWorkSel(json_body);
	}


	/**
	 {
	 }
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="키오스크 상태 저장")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_TERMINAL_CODE\":\"1000\",\r\n" +
							"        	\"I_KIOSKID\":\"1002\",\r\n" +
							"        	\"I_VERSION\":\"1.0.0.0\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/kioskStatusSav")
	public @ResponseBody Map<String, Object> kioskStatusSav(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return kioskService.kioskStatusSav(json_body);
	}


	/**
	 {
	 "id":"user",
	 "password":"password"
	 }
	 * @param json_body
	 * @return
	 * @throws
	 */
	@ApiOperation(value="로그인")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_ID\":\"8465\",\r\n" +
							"        	\"I_PASS\":\"8465\",\r\n" +
							"        	\"I_MIN_NO\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/driverLogin")
	public @ResponseBody Map<String, Object> driverLogin(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body) throws NoSuchAlgorithmException {

		// 암호화하여 다시넣는다..
		String orgString = json_body.get("I_PASS").toString();
		String encString = SysUtils.encryptSHA256(orgString);
		json_body.put("I_PASS", encString);

		return kioskService.driverLogin(json_body);
	}

//	/**
//	 {
//
//	 }
//	 * @param json_body
//	 * @return
//	 */
//	@ApiOperation(value="차량조회")
//	@ApiImplicitParams({
//			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
//			@ApiImplicitParam(name = "json_body",
//					value =  "        {\r\n" +
//							"        }",
//					required = true, dataType = "object", paramType = "body")
//	})
//	@CrossOrigin("*")
//	@PostMapping(value="/getDrivingCar")
//	public @ResponseBody Map<String, Object> searchCar(@RequestHeader String api_key, @RequestBody Map<String, Object> json_body){
//		return kioskService.getDrivingCar(json_body);
//	}


	/**
	 {

	 }
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="지문조회")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_ID\":\"36\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/getFingerPrint")
	public @ResponseBody Map<String, Object> getFingerPrint(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return kioskService.getFingerPrint(json_body);
	}


//	/**
//	 {
//
//	 }
//	 * @param json_body
//	 * @return
//	 */
//	@ApiOperation(value="주문조회")
//	@ApiImplicitParams({
//			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
//			@ApiImplicitParam(name = "json_body",
//					value =  "        {\r\n" +
//							"        }",
//					required = true, dataType = "object", paramType = "body")
//	})
//	@CrossOrigin("*")
//	@PostMapping(value="/getOrder")
//	public @ResponseBody Map<String, Object> getOrder(@RequestHeader String api_key, @RequestBody Map<String, Object> json_body){
//		return kioskService.getOrder(json_body);
//	}

	/**
	 * @param api_key
	 * *
	 @param json_body
	  * @return
	 */
	@ApiOperation(value="배차내역, 조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_PLANT_LIST\":\"3341:1,3741:1,4086:2,4091:2,4800:2,4801:2\",\r\n" +
							"        	\"I_SHIPMENT_FROM_DT\":\"20220708\",\r\n" +
							"        	\"I_SHIPMENT_TO_DT\":\"20220708\",\r\n" +
							"        	\"I_DRV_CD\":\"2363\",\r\n" +
							"        	\"I_VEHICLE_CD\":\"92-4136\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/dispatchListSel")
	public @ResponseBody
	Map<String, Object> dispatchListSel(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){

		String plantList = json_body.get("I_PLANT_LIST").toString();
		String vehicleNo = json_body.get("I_VEHICLE_CD").toString();
		String fromDate = json_body.get("I_SHIPMENT_FROM_DT").toString();
		String toDate = json_body.get("I_SHIPMENT_TO_DT").toString();

		Map<String, Object> eaiResult = new LinkedHashMap<String, Object>();
		eaiResult = eaiService.disDispatchDisplay(plantList, vehicleNo, fromDate, toDate);

		// 데이타 추출..
		JSONObject jsonObject = new JSONObject(eaiResult);
		String jsonData = jsonObject.toString();
		JsonElement jelement = new JsonParser().parse(jsonData);
		JsonObject jObject = jelement.getAsJsonObject();
		String resultCode = jObject.get("resultCode").getAsString();
		String resultMsg = jObject.get("resultMsg").getAsString();

		List<KioskDispatchListDto> kioskDispatchListDtos = new ArrayList<KioskDispatchListDto>();

		Map<String, Object> resultMap = new LinkedHashMap<String, Object>();
		if (!jObject.get("resultData").isJsonNull())
		{
			JsonArray jarrayRecordSet = jObject.get("resultData").getAsJsonArray();

			for (int index = 0; index < jarrayRecordSet.size(); ++index) {
				JsonObject jobjectStore = jarrayRecordSet.get(index).getAsJsonObject();
				System.out.println(String.format("[%d]%s", index, jobjectStore.toString()));

				KioskDispatchListDto kioskDispatchListDto = new KioskDispatchListDto();

				kioskDispatchListDto.SHNUMBER = String.format("%s", jobjectStore.get("SHNUMBER")).replace("\"", "");
				kioskDispatchListDto.SHN_SEQ = String.format("%s", jobjectStore.get("TRIP")).replace("\"", "");
				kioskDispatchListDto.LOADING_REQUEST_ID = "";
				kioskDispatchListDto.REQUEST_DATE = String.format("%s", jobjectStore.get("SCHED_STDT")).replace("\"", "").replace("-", "");
				kioskDispatchListDto.REQUEST_TIME = String.format("%s", jobjectStore.get("SCHED_STTM")).replace("\"", "").replace(":", "");
				kioskDispatchListDto.SOURCE_CD = String.format("%s", jobjectStore.get("WERKS")).replace("\"", "");
				kioskDispatchListDto.SOURCE_NM = String.format("%s", jobjectStore.get("WERKS_NM")).replace("\"", "");
				kioskDispatchListDto.CUST_CD = String.format("%s", jobjectStore.get("KUNWE")).replace("\"", "");
				kioskDispatchListDto.CUST_NM = String.format("%s", jobjectStore.get("KUNWE_NM")).replace("\"", "");
				kioskDispatchListDto.CUST_ADDRESS = "";
				kioskDispatchListDto.ITEM_NM = String.format("%s", jobjectStore.get("ARKTX")).replace("\"", "");
				kioskDispatchListDto.SHIPMENT_VOLUME = String.format("%s", jobjectStore.get("SCH_QTY")).replace("\"", "");
				kioskDispatchListDto.SHIP_METHOD = String.format("%s", jobjectStore.get("ZGNTYPE")).replace("\"", "");
				kioskDispatchListDto.CARD_YN = "";
				kioskDispatchListDto.CARD_NO = "";
				kioskDispatchListDto.SEAL_YN = String.format("%s", jobjectStore.get("ZSEALYN")).replace("\"", "");
				kioskDispatchListDto.VEHICLE_CD = String.format("%s", jobjectStore.get("VEHICLE")).replace("\"", "");
				kioskDispatchListDto.LOADING_KEY = "";

				kioskDispatchListDtos.add(kioskDispatchListDto);
			}
		}

		resultMap.put("resultCode", "00"); // resultCode);
		resultMap.put("resultMsg", resultMsg);
		resultMap.put("resultData",  kioskDispatchListDtos);

		return resultMap;

		// return kioskService.dispatchListSel(json_body);
	}

	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="배차선택\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_PLANT_CD\":\"2010\",\r\n" +
							"        	\"I_SHIPMENT_NO\":\"\",\r\n" +
							"        	\"I_SHIPMENT_DT\":\"20220830\",\r\n" +
							"        	\"I_DRV_CD\":\"11786\",\r\n" +
							"        	\"I_VEHICLE_CD\":\"85-9580\",\r\n" +
							"        	\"I_SEAL_START\":\"\",\r\n" +
							"        	\"I_SEAL_END\":\"\",\r\n" +
							"        	\"I_SHIP_KEY\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/dispatchSelectSav")
	public @ResponseBody Map<String, Object> dispatchSelectSav(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return kioskService.dispatchSelectSav(json_body);
	}


	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="출하요청, 저장\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_SHIPMENT_NO\" : \"8804962\", \r\n" +
							"        	\"I_SHIPMENT_DT\" : \"20220708\", \r\n" +
							"        	\"I_DRV_CD\" : \"2363\", \r\n" +
							"        	\"I_VEHICLE_CD\" : \"92-4136\", \r\n" +
							"        	\"I_MIN_NO\" : \"\", \r\n" +
							"        	\"I_WERKS\" : \"2010\", \r\n" +
							"        	\"I_GUBUN_FG\" : \"K\", \r\n" +
							"        	\"I_LOADING_KEY_NO1\" : \"\", \r\n" +
							"        	\"I_LOADING_KEY_NO2\" : \"\", \r\n" +
							"        	\"I_RANDOM_KEY_NO1\" : \"\", \r\n" +
							"        	\"I_RANDOM_KEY_NO2\" : \"\", \r\n" +
							"        	\"I_SEALING_NO1\" : \"\", \r\n" +
							"        	\"I_SEALING_NO2\" : \"\", \r\n" +
							"        	\"I_RANDOM_KEY_YN\" : \"\", \r\n" +
							"        	\"I_RESULT_INPUT_YN\" : \"\", \r\n" +
							"        	\"I_LAT\" : \"\", \r\n" +
							"        	\"I_LON\" : \"\", \r\n" +
							"        	\"I_DISPATCH_NO\" : \"\", \r\n" +
							"        	\"I_DELI_NO\" : \"\", \r\n" +
							"        	\"I_ROUTE_SEQ\" : \"\", \r\n" +
							"        	\"I_STOP_SEQ\" : \"\" \r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/shippingCreateSav")
	public @ResponseBody Map<String, Object> shippingCreateSav(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){

		Map<String, Object> shippingCreateSavResult = new LinkedHashMap<String, Object>();
		Map<String, Object> checkResult = new LinkedHashMap<String, Object>();

		try {

			String I_SHIPMENT_NO = json_body.get("I_SHIPMENT_NO").toString();
			String fromDate = json_body.get("I_SHIPMENT_DT").toString();
			String toDate = json_body.get("I_SHIPMENT_DT").toString();
			String drvCd = json_body.get("I_DRV_CD").toString();
			String vehicleNo = json_body.get("I_VEHICLE_CD").toString();
			String minNo = json_body.get("I_MIN_NO").toString();
			String plantCd = json_body.get("I_WERKS").toString();
			String I_GUBUN_FG = json_body.get("I_GUBUN_FG").toString(); // K:키오스크, M:모바일
			String I_LOADING_KEY_NO1 = (json_body.get("I_LOADING_KEY_NO1") == null) ? "":json_body.get("I_LOADING_KEY_NO1").toString();
			String I_LOADING_KEY_NO2 = (json_body.get("I_LOADING_KEY_NO2") == null) ? "":json_body.get("I_LOADING_KEY_NO2").toString();
			String I_RANDOM_KEY_NO1 = (json_body.get("I_RANDOM_KEY_NO1") == null) ? "":json_body.get("I_RANDOM_KEY_NO1").toString();
			String I_RANDOM_KEY_NO2 = (json_body.get("I_RANDOM_KEY_NO2") == null) ? "":json_body.get("I_RANDOM_KEY_NO2").toString();
			String I_SEALING_NO1 = (json_body.get("I_SEALING_NO1") == null) ? "":json_body.get("I_SEALING_NO1").toString();
			String I_SEALING_NO2 = (json_body.get("I_SEALING_NO2") == null) ? "":json_body.get("I_SEALING_NO2").toString();
			String I_RANDOM_KEY_YN = (json_body.get("I_RANDOM_KEY_YN") == null) ? "":json_body.get("I_RANDOM_KEY_YN").toString();
			String I_RESULT_INPUT_YN = (json_body.get("I_RESULT_INPUT_YN") == null) ? "":json_body.get("I_RESULT_INPUT_YN").toString();
			String I_LAT = "";
			String I_LON = "";
			String I_DISPATCH_NO = "";
			String I_DELI_NO = "";
			String I_ROUTE_SEQ = "";
			String I_STOP_SEQ = "";
			if (I_GUBUN_FG.equals("K")) {
				// 키오스크
				I_LAT = "";
				I_LON = "";
				I_DISPATCH_NO = "";
				I_DELI_NO = "";
				I_ROUTE_SEQ = "";
				I_STOP_SEQ = "";
			} else {
				// 모바일
				I_LAT = json_body.get("I_LAT").toString();
				I_LON = json_body.get("I_LON").toString();
				I_DISPATCH_NO = json_body.get("I_DISPATCH_NO").toString();
				I_DELI_NO = json_body.get("I_DELI_NO").toString();
				I_ROUTE_SEQ = json_body.get("I_ROUTE_SEQ").toString();
				I_STOP_SEQ = json_body.get("I_STOP_SEQ").toString();
			}


			Map<String, Object> eaiDispResult = new LinkedHashMap<String, Object>();
			//eaiDispResult = eaiService.disDispatchDisplay(plantCd, vehicleNo, fromDate, toDate);
			eaiDispResult = eaiService.disDispatchDisplay("", vehicleNo, fromDate, toDate); // 플랜트리스트를 비운다.(전체 대상) - 2022.12.16 혹한기출하관련 보완작업 추가코드..

			// 데이타 추출..
			JSONObject jsonObjectDispResult = new JSONObject(eaiDispResult);
			String jsonDataDispResult = jsonObjectDispResult.toString();
			JsonElement jelementDispResult = new JsonParser().parse(jsonDataDispResult);
			JsonObject jObjectDispResult = jelementDispResult.getAsJsonObject();
			String resultCode = jObjectDispResult.get("resultCode").getAsString();
			String resultMsg = jObjectDispResult.get("resultMsg").getAsString();

			// List<KioskDispatchListDto> kioskDispatchListDtos = new ArrayList<KioskDispatchListDto>();

			Map<String, Object> eaiShipCreateResult = new LinkedHashMap<String, Object>();

			if (jObjectDispResult.get("resultData") != null) {
				JsonArray jarrayDispResult = jObjectDispResult.get("resultData").getAsJsonArray();
				int nDataCount = 0;
				// 출하요청 대상 선적번호 찾기
				for (int idx = 0; idx < jarrayDispResult.size(); ++idx) {
					JsonObject jobjectStore = jarrayDispResult.get(idx).getAsJsonObject();
					String shNumber = jobjectStore.get("SHNUMBER").getAsString();
					// 요청하는 선적번호를 찾는다..
					if (I_SHIPMENT_NO.equals(shNumber)) {
						nDataCount++;
					}
				}

				HashMap[] hashMaps = new HashMap[nDataCount];
				int nSaveIndex = 0;
				for (int index = 0; index < jarrayDispResult.size(); ++index) {
					JsonObject jobjDispResult = jarrayDispResult.get(index).getAsJsonObject();
					//System.out.println(String.format("[%d]%s", index, jobjectStore.toString()));
					// 요청하는 선적번호를 찾는다..
					String shNumber = jobjDispResult.get("SHNUMBER").getAsString();
					if (I_SHIPMENT_NO.equals(shNumber)) {
						hashMaps[nSaveIndex] = new HashMap();
						hashMaps[nSaveIndex].put("SHNUMBER", jobjDispResult.get("SHNUMBER").getAsString());
						hashMaps[nSaveIndex].put("VBELN", jobjDispResult.get("VBELN").getAsString());
						hashMaps[nSaveIndex].put("POSNN", jobjDispResult.get("POSNN").getAsString());
						hashMaps[nSaveIndex].put("WERKS", jobjDispResult.get("WERKS").getAsString());
						hashMaps[nSaveIndex].put("MATNR", jobjDispResult.get("MATNR").getAsString());
						hashMaps[nSaveIndex].put("SCH_QTY", jobjDispResult.get("SCH_QTY").getAsString());
						hashMaps[nSaveIndex].put("SCH_UOM", jobjDispResult.get("SCH_UOM").getAsString());
						if (I_LOADING_KEY_NO1.isEmpty()) {
							hashMaps[nSaveIndex].put("CARDNO01", I_RANDOM_KEY_NO1);
							hashMaps[nSaveIndex].put("CARDNO02", "");
						} else {
							hashMaps[nSaveIndex].put("CARDNO01", I_LOADING_KEY_NO1);
							hashMaps[nSaveIndex].put("CARDNO02", "");
						}
						hashMaps[nSaveIndex].put("ZSEALNO", I_SEALING_NO1 + "-" + I_SEALING_NO2);
						nSaveIndex++;

						// ----------------------------------------------------------------------------------------------------
						// 출하제약조건 확인...
						// ----------------------------------------------------------------------------------------------------
						checkResult = kioskService.checkShippingCheclSel(
								jobjDispResult.get("WERKS").getAsString(),
								vehicleNo,
								drvCd,
								jobjDispResult.get("SHNUMBER").getAsString(),
								jobjDispResult.get("VBELN").getAsString(),
								jobjDispResult.get("POSNN").getAsString(),
								jobjDispResult.get("VSBED").getAsString(),
								jobjDispResult.get("MATNR").getAsString()
						);
						// 결과데이터 처리..
						JSONObject jsonObject = new JSONObject(checkResult);
						String jsonData = jsonObject.toString();
						JsonElement jelement = new JsonParser().parse(jsonData);
						JsonObject retObj = jelement.getAsJsonObject();

						String checkResultCode = retObj.get("resultCode").getAsString();
						String checkResultMsg = retObj.get("resultMsg").getAsString();

						if (checkResultCode.equals("-1")) {
							// 출하제약조건 위배
							return checkResult;
						}
					}
				}

				// EAI 정상호출
				String ZIFDAT = SysUtils.getToday();
				String ZIFTIM = SysUtils.getCurrentTime("HHmmss");
				if (I_RANDOM_KEY_YN.equals("Y")) {
					eaiShipCreateResult = eaiService.disShippingCreateRan(ZIFDAT, ZIFTIM, vehicleNo, drvCd, hashMaps);
				} else {
					eaiShipCreateResult = eaiService.disShippingCreate(ZIFDAT, ZIFTIM, vehicleNo, drvCd, hashMaps);
				}

				// EAI호출결과, 데이타 추출..
				JSONObject jsonObjectEai = new JSONObject(eaiShipCreateResult);
				String jsonDataEai = jsonObjectEai.toString();
				JsonElement jelementEai = new JsonParser().parse(jsonDataEai);
				JsonObject jObjectEai = jelementEai.getAsJsonObject();
				String resultTypeEai = jObjectEai.get("resultType").getAsString();
				String resultCodeEai = jObjectEai.get("resultCode").getAsString();
				String resultMsgEai = jObjectEai.get("resultMsg").getAsString();

				String MSGTYP = resultTypeEai;
				String MSGNUM = resultCodeEai;
				String MSGTXT = resultMsgEai;
				if (resultCodeEai.equals("100")) {
					MSGTYP = "S";
				} else {
//					if (resultCodeEai.equals("046")) { // 개발용 046 오류는 정상처리...
//						MSGTYP = "S";
//					} else {
					MSGTYP = "E";
//					}
				}

				// EAI 주석처리시, 필요..
//				String ZIFDAT = SysUtils.getToday();
//				String ZIFTIM = SysUtils.getCurrentTime("HHmmss");
//				String MSGTYP = "S";
//				String MSGNUM = "999";
//				String MSGTXT = "[개발용]EAI 호출 SKIP..! ";

				// DIT_IF_LOADING_REQUEST 테이블에 저장...
				nSaveIndex = 0;
				for (int index = 0; index < jarrayDispResult.size(); ++index) {
					JsonObject jobjectStore = jarrayDispResult.get(index).getAsJsonObject();
					//System.out.println(String.format("[%d]%s", index, jobjectStore.toString()));
					// 요청하는 선적번호를 찾는다..
					String shNumber = jobjectStore.get("SHNUMBER").getAsString();
					if (I_SHIPMENT_NO.equals(shNumber)) {
						LinkedHashMap<String, Object> params = new LinkedHashMap<String, Object>();
						// EAI 데이터
						params.put("RANDOM_KEY_YN", I_RANDOM_KEY_YN);
						params.put("ZIFDAT", ZIFDAT);
						params.put("ZIFTIM", ZIFTIM);
						params.put("VEHICLE", vehicleNo);
						params.put("DRIVERCODE", drvCd);
						params.put("SHNUMBER", jobjectStore.get("SHNUMBER").getAsString());
						params.put("VBELN", jobjectStore.get("VBELN").getAsString());
						params.put("POSNN", jobjectStore.get("POSNN").getAsString());
						params.put("WERKS", jobjectStore.get("WERKS").getAsString());
						params.put("MATNR", jobjectStore.get("MATNR").getAsString());
						params.put("SCH_QTY", jobjectStore.get("SCH_QTY").getAsString());
						params.put("SCH_UOM", jobjectStore.get("SCH_UOM").getAsString());
						if (I_LOADING_KEY_NO1.isEmpty()) {
							params.put("CARDNO01", I_RANDOM_KEY_NO1);
							params.put("CARDNO02", "");
						} else {
							params.put("CARDNO01", I_LOADING_KEY_NO1);
							params.put("CARDNO02", "");
						}
						params.put("ZSEALNO", I_SEALING_NO1 + "-" + I_SEALING_NO2);
						params.put("VSBED", jobjectStore.get("VSBED").getAsString());
						params.put("VBELV", jobjectStore.get("VBELV").getAsString());
						params.put("POSNV", jobjectStore.get("POSNV").getAsString());
						params.put("KUNAG", jobjectStore.get("KUNAG").getAsString());
						params.put("KUNAG_NM", jobjectStore.get("KUNAG_NM").getAsString());
						params.put("KUNWE", jobjectStore.get("KUNWE").getAsString());
						params.put("KUNWE_NM", jobjectStore.get("KUNWE_NM").getAsString());
						params.put("WERKS_NM", jobjectStore.get("WERKS_NM").getAsString());
						params.put("LFART", jobjectStore.get("LFART").getAsString());
						params.put("LFART_NM", jobjectStore.get("LFART_NM").getAsString());
						params.put("ARKTX", jobjectStore.get("ARKTX").getAsString());
						params.put("OIGNRULE", jobjectStore.get("OIGNRULE").getAsString());
						params.put("SCHED_STDT", jobjectStore.get("SCHED_STDT").getAsString());
						params.put("SCHED_STTM", jobjectStore.get("SCHED_STTM").getAsString());
						params.put("VEH_TEXT", jobjectStore.get("VEH_TEXT").getAsString());
						params.put("CARRIER", jobjectStore.get("CARRIER").getAsString());
						params.put("CARRIER_NM", jobjectStore.get("CARRIER_NM").getAsString());
						params.put("ZZVECODE", jobjectStore.get("ZZVECODE").getAsString());
						params.put("ZZVECODE_TEXT", jobjectStore.get("ZZVECODE_TEXT").getAsString());
						params.put("TRIP", jobjectStore.get("TRIP").getAsString());
						params.put("VSBED_NM", jobjectStore.get("VSBED_NM").getAsString());
						params.put("PUR_FLAG", jobjectStore.get("PUR_FLAG").getAsString());
						params.put("SAM_FLAG", jobjectStore.get("SAM_FLAG").getAsString());
						params.put("ZSEALYN", jobjectStore.get("ZSEALYN").getAsString());
						params.put("ZGNTYPE", jobjectStore.get("ZGNTYPE").getAsString());

						if (jobjectStore.has("SHV_SEQ")) {
							params.put("SHV_SEQ", jobjectStore.get("SHV_SEQ").getAsString());
						} else {
							params.put("SHV_SEQ", "");
						}
						// 단말기 구분(K:키오스크, M:모바일)
						params.put("I_GUBUN_FG", I_GUBUN_FG);

						// KIOSK 데이터
						params.put("I_DRV_CD", drvCd);
						params.put("I_VEHICLE_CD", vehicleNo);

						//MOBILE 데이터
						params.put("I_MIN_NO", minNo);
						params.put("I_LAT", I_LAT);
						params.put("I_LON", I_LON);
						params.put("I_DISPATCH_NO", I_DISPATCH_NO);
						params.put("I_DELI_NO", I_DELI_NO);
						params.put("I_ROUTE_SEQ", I_ROUTE_SEQ);
						params.put("I_DRV_CD", drvCd);
						params.put("I_STOP_SEQ", I_STOP_SEQ);

						// 서버에서 추가하는 EAI호출결과 데이터
						params.put("MSGTYP", MSGTYP);
						params.put("MSGNUM", MSGNUM);
						params.put("MSGTXT", MSGTXT);

						shippingCreateSavResult = kioskService.shippingCreateSav(params);
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return shippingCreateSavResult;
	}

	/**
	 * @param api_key
	 * *
	 @param json_body
	  * @return
	 */
	@ApiOperation(value="출하전표발행, 출하내역 조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_SHIPMENT_DT\":\"20220403\",\r\n" +
							"        	\"I_DRV_CD\":\"8408\",\r\n" +
							"        	\"I_VEHICLE_CD\":\"85-9866\",\r\n" +
							"        	\"I_MIN_NO\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/shippingResultSel")
	public @ResponseBody
	Map<String, Object> shippingResultSel(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return kioskService.shippingResultSel(json_body);
	}

	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="출하전표발행, 결과입력 저장\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_SHIPMENT_NO\" : \"10097313\", \r\n" +
							"        	\"I_SHIPMENT_DT\":\"20220403\",\r\n" +
							"        	\"I_DRV_CD\":\"8408\",\r\n" +
							"        	\"I_VEHICLE_CD\":\"85-9866\",\r\n" +
							"        	\"I_MIN_NO\":\"\",\r\n" +
							"        	\"I_TMP_VAL\":\"\",\r\n" +
							"        	\"I_DEN_VAL\":\"\",\r\n" +
							"        	\"I_CNV_VAL\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/shippingResultSav")
	public @ResponseBody Map<String, Object> shippingResultSav(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return kioskService.shippingResultSav(json_body);
	}

	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="출하전표발행, 출력요청\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_SHIPMENT_NO\" : \"10097313\", \r\n" +
							"        	\"I_SHIPMENT_DT\":\"20220403\",\r\n" +
							"        	\"I_DRV_CD\":\"8408\",\r\n" +
							"        	\"I_VEHICLE_CD\":\"85-9866\",\r\n" +
							"        	\"I_MIN_NO\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/ticketCreateSav")
	public @ResponseBody Map<String, Object> ticketCreateSav(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return kioskService.ticketCreateSav(json_body);
	}



	/**
	 * @param api_key
	 * *
	 @param json_body
	  * @return
	 */
	@ApiOperation(value="[EAI] 배차내역, 조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"TERMINAL_CODE\":\"2010\",\r\n" +
							"        	\"PLANT_LIST\":\"2010\",\r\n" +
							"        	\"VEHICLE\":\"85-3368\",\r\n" +
							"        	\"ZFRDAT\":\"20220820\",\r\n" +
							"        	\"ZTODAT\":\"20220820\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/eai/disDispatchDisplay")
	public @ResponseBody
	Map<String, Object> disDispatchDisplay(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){

		String terminalCode = json_body.get("TERMINAL_CODE").toString();
		String plantList = json_body.get("PLANT_LIST").toString();
		String vehicleNo = json_body.get("VEHICLE").toString();
		String fromDate = json_body.get("ZFRDAT").toString();
		String toDate = json_body.get("ZTODAT").toString();

		return eaiService.disDispatchDisplay(plantList, vehicleNo, fromDate, toDate);
	}

	/**
	 * @param api_key
	 * *
	 @param json_body
	  * @return
	 */
	@ApiOperation(value="[EAI] 출하실적, 조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"PLANT_LIST\":\"3341:1,3741:1,4086:2,4091:2,4800:2,4801:2\",\r\n" +
							"        	\"VEHICLE\":\"82-2264A\",\r\n" +
							"        	\"ZFRDAT\":\"20220901\",\r\n" +
							"        	\"ZTODAT\":\"20220901\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/eai/disLoadingResultDisplay")
	public @ResponseBody
	Map<String, Object> disLoadingResultDisplay(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){

		String plantList = json_body.get("I_PLANT_LIST").toString();
		String vehicle = json_body.get("I_VEHICLE").toString();
		String fromDate = json_body.get("I_ZFRDAT").toString();
		String toDate = json_body.get("I_ZTODAT").toString();

		return eaiService.disLoadingResultDisplay(plantList, vehicle, fromDate, toDate);
	}


	/**
	 * @param api_key
	 * *
	 @param json_body
	  * @return
	 */
	@ApiOperation(value="[EAI] 출하결과 입력\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_VEHICLE\":\"85-9115\",\r\n" +
							"        	\"I_ZFRDAT\":\"20220629\",\r\n" +
							"        	\"I_ZTODAT\":\"20220629\",\r\n" +
							"        	\"I_SHUNNUMBER_STRING\":\"8804912\",\r\n" +
							"        	\"I_VBELN_STRING\":\"305531045\",\r\n" +
							"        	\"I_POSNN_STRING\":\"10\",\r\n" +
							"        	\"I_WERKS\":\"2010\",\r\n" +
							"        	\"I_LOAD_EDDTA\":\"2022-06-29\",\r\n" +
							"        	\"I_MATNR\":\"10270\",\r\n" +
							"        	\"I_GRS_QTY\":\"\",\r\n" +
							"        	\"I_GRS_UOM\":\"\",\r\n" +
							"        	\"I_NET_QTY\":\"\",\r\n" +
							"        	\"I_NET_UOM\":\"\",\r\n" +
							"        	\"I_TMP_VAL\":\"\",\r\n" +
							"        	\"I_TMP_UOM\":\"\",\r\n" +
							"        	\"I_DEN_VAL\":\"\",\r\n" +
							"        	\"I_ZACTGB\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/eai/disLoadingTicketCreate")
	public @ResponseBody
	Map<String, Object> disLoadingTicketCreate(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){

		String I_VEHICLE = json_body.get("I_VEHICLE").toString();
		String I_ZFRDAT = json_body.get("I_ZFRDAT").toString();
		String I_ZTODAT = json_body.get("I_ZTODAT").toString();
		String I_SHUNNUMBER = json_body.get("I_SHUNNUMBER").toString();
		String I_VBELN = json_body.get("I_VBELN").toString();
		String I_POSNN = json_body.get("I_POSNN").toString();
		String I_WERKS = json_body.get("I_WERKS").toString();
		String I_LOAD_EDDTA = json_body.get("I_LOAD_EDDTA").toString();
		String I_MATNR = json_body.get("I_MATNR").toString();
		String I_GRS_QTY = json_body.get("I_GRS_QTY").toString();
		String I_GRS_UOM = json_body.get("I_GRS_UOM").toString();
		String I_NET_QTY = json_body.get("I_NET_QTY").toString();
		String I_NET_UOM = json_body.get("I_NET_UOM").toString();
		String I_TMP_VAL = json_body.get("I_TMP_VAL").toString();
		String I_TMP_UOM = json_body.get("I_TMP_UOM").toString();
		String I_DEN_VAL = json_body.get("I_DEN_VAL").toString();
		String I_ZACTGB = json_body.get("I_ZACTGB").toString();
		String ZIFTIM = SysUtils.getCurrentTime("HHmmss");

//		HashMap[] hashMaps = new HashMap[1];
//		hashMaps[0] = new HashMap();
//		hashMaps[0].put("SHNUMBER", I_SHNUMBER); // TD 선적 번호, PK
//		hashMaps[0].put("VBELN", I_VBELN); // 납품문서번호, PK
//		hashMaps[0].put("POSNN", I_POSNN); // 납품문서품목, PK
//		hashMaps[0].put("WERKS", I_WERKS); // 출하처(플랜트 Code)
//		hashMaps[0].put("LOAD_EDDTA", I_LOAD_EDDTA); // 적재일자(전기일)	"적재 결과 입력된 경우 (12.03)"
//		hashMaps[0].put("MATNR", I_MATNR); // 제품코드
//		hashMaps[0].put("GRS_QTY", I_GRS_QTY); // 적재 Gross 수량("L" 통일)	"000000020000" 형식
//		hashMaps[0].put("GRS_UOM", I_GRS_UOM); // 적재 Gross 수량단위	ISO 기준 UOM 사용
//		hashMaps[0].put("NET_QTY", I_NET_QTY); // 적재 Net 수량("L15" 통일)	"000000020000" 형식
//		hashMaps[0].put("NET_UOM", I_NET_UOM); // 적재 Net 수량단위	ISO 기준 UOM 사용
//		hashMaps[0].put("TMP_VAL", I_TMP_VAL); // 적재 온도("CEL" 통일)	057.9+ or 057.9-
//		hashMaps[0].put("TMP_UOM", I_TMP_UOM); // 적재 온도단위	ISO 기준 UOM 사용
//		hashMaps[0].put("DEN_VAL", I_DEN_VAL); // 적재 밀도	0887.5

		String arrI_VEHICLE[] = I_VEHICLE.split(",");
		String arrI_ZFRDAT[] = I_ZFRDAT.split(",");
		String arrI_ZTODAT[] = I_ZTODAT.split(",");
		String arrI_SHUNNUMBER[] = I_SHUNNUMBER.split(",");
		String arrI_VBELN[] = I_VBELN.split(",");
		String arrI_POSNN[] = I_POSNN.split(",");
		String arrI_WERKS[] = I_WERKS.split(",");
		String arrI_LOAD_EDDTA[] = I_LOAD_EDDTA.split(",");
		String arrI_MATNR[] = I_MATNR.split(",");
		String arrI_GRS_QTY[] = I_GRS_QTY.split(",");
		String arrI_GRS_UOM[] = I_GRS_UOM.split(",");
		String arrI_NET_QTY[] = I_NET_QTY.split(",");
		String arrI_NET_UOM[] = I_NET_UOM.split(",");
		String arrI_TMP_VAL[] = I_TMP_VAL.split(",");
		String arrI_TMP_UOM[] = I_TMP_UOM.split(",");
		String arrI_DEN_VAL[] = I_DEN_VAL.split(",");

		HashMap[] hashMaps = new HashMap[arrI_VEHICLE.length];	// 실제 전송할 HashMap

		for(int i=0; i<arrI_VEHICLE.length; i++) {

			String SHNUMBER = arrI_SHUNNUMBER[i];
			String VBELN = arrI_VBELN[i];
			String POSNN = arrI_POSNN[i];
			String WERKS = arrI_WERKS[i];
			String LOAD_EDDTA = arrI_LOAD_EDDTA[i].replace("-", "");
			String MATNR = arrI_MATNR[i];
			String GRS_QTY = (arrI_GRS_QTY.length>0) ? arrI_GRS_QTY[i] : "";
			String GRS_UOM = (arrI_GRS_UOM.length>0) ? arrI_GRS_UOM[i] : "";
			String NET_QTY = (arrI_NET_QTY.length>0) ? arrI_NET_QTY[i] : "0";
			String NET_UOM = (arrI_NET_UOM.length>0) ? arrI_NET_UOM[i] : "L15";
			String TMP_VAL = (arrI_TMP_VAL.length>0) ? arrI_TMP_VAL[i] : "0";
			String TMP_UOM = (arrI_TMP_UOM.length>0) ? arrI_TMP_UOM[i] : "CEL";
			String DEN_VAL = (arrI_DEN_VAL.length>0) ? arrI_DEN_VAL[i] : "";

			hashMaps[i] = new HashMap();
			hashMaps[i].put("SHNUMBER", SHNUMBER);
			hashMaps[i].put("VBELN", VBELN);
			hashMaps[i].put("POSNN", POSNN);
			hashMaps[i].put("WERKS", WERKS);
			hashMaps[i].put("LOAD_EDDTA", LOAD_EDDTA);
			hashMaps[i].put("MATNR", MATNR);
			hashMaps[i].put("GRS_QTY", GRS_QTY);
			hashMaps[i].put("GRS_UOM", GRS_UOM);
			hashMaps[i].put("NET_QTY", NET_QTY);
			hashMaps[i].put("NET_UOM", NET_UOM);
			hashMaps[i].put("TMP_VAL", TMP_VAL);
			hashMaps[i].put("TMP_UOM", TMP_UOM);
			hashMaps[i].put("DEN_VAL", DEN_VAL);
		}

		String vehicleNo = arrI_VEHICLE[0];
		String fromDate = arrI_ZFRDAT[0];
		String toDate = arrI_ZTODAT[0];

		return eaiService.disLoadingTicketCreate(vehicleNo, fromDate, toDate, I_ZACTGB, ZIFTIM, hashMaps);
	}

	/**
	 * @param api_key
	 * *
	 @param json_body
	  * @return
	 */
	@ApiOperation(value="[EAI] 출하요청\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"ZIFDAT\":\"\",\r\n" +
							"        	\"ZIFTIM\":\"\",\r\n" +
							"        	\"VEHICLE\":\"\",\r\n" +
							"        	\"DRIVERCODE\":\"\",\r\n" +
							"        	\"SHIPMENT_NO\":\"\",\r\n" +
							"        	\"VBELN\":\"\",\r\n" +
							"        	\"POSNN\":\"\",\r\n" +
							"        	\"WERKS\":\"\",\r\n" +
							"        	\"MATNR\":\"\",\r\n" +
							"        	\"SCH_QTY\":\"\",\r\n" +
							"        	\"SCH_UOM\":\"\",\r\n" +
							"        	\"LOADING_KEY_NO1\":\"\",\r\n" +
							"        	\"LOADING_KEY_NO2\":\"\",\r\n" +
							"        	\"SEALING_NO\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/eai/disShippingCreate")
	public @ResponseBody
	Map<String, Object> disShippingCreate(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){

		String ZIFDAT = json_body.get("ZIFDAT").toString();
		String ZIFTIM = json_body.get("ZIFTIM").toString();
		String VEHICLE = json_body.get("VEHICLE").toString();
		String DRIVERCODE = json_body.get("DRIVERCODE").toString();

		String SHIPMENT_NO = json_body.get("SHIPMENT_NO").toString();
		String VBELN = json_body.get("VBELN").toString();
		String POSNN = json_body.get("POSNN").toString();
		String WERKS = json_body.get("WERKS").toString();
		String MATNR = json_body.get("MATNR").toString();
		String SCH_QTY = json_body.get("SCH_QTY").toString();
		String SCH_UOM = json_body.get("SCH_UOM").toString();
		String LOADING_KEY_NO1 = json_body.get("LOADING_KEY_NO1").toString();
		String LOADING_KEY_NO2 = json_body.get("LOADING_KEY_NO2").toString();
		String SEALING_NO = json_body.get("SEALING_NO").toString();

		HashMap[] hashMaps = new HashMap[1];
		hashMaps[0] = new HashMap();
		hashMaps[0].put("SHIPMENT_NO", SHIPMENT_NO);
		hashMaps[0].put("VBELN", VBELN);
		hashMaps[0].put("POSNN", POSNN);
		hashMaps[0].put("WERKS", WERKS);
		hashMaps[0].put("MATNR", MATNR);
		hashMaps[0].put("SCH_QTY", SCH_QTY);
		hashMaps[0].put("SCH_UOM", SCH_UOM);
		hashMaps[0].put("LOADING_KEY_NO1", LOADING_KEY_NO1);
		hashMaps[0].put("LOADING_KEY_NO2", LOADING_KEY_NO2);
		hashMaps[0].put("SEALING_NO", SEALING_NO);

		return eaiService.disShippingCreate(ZIFDAT, ZIFTIM, VEHICLE, DRIVERCODE, hashMaps);
	}



	/**
	 * @param api_key
	 * *
	 @param json_body
	  * @return
	 */
	@ApiOperation(value="[EAI] 출하요청-DIS전용\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"ZIFDAT\":\"\",\r\n" +
							"        	\"ZIFTIM\":\"\",\r\n" +
							"        	\"VEHICLE\":\"\",\r\n" +
							"        	\"DRIVERCODE\":\"\",\r\n" +
							"        	\"SHIPMENT_NO\":\"\",\r\n" +
							"        	\"VBELN\":\"\",\r\n" +
							"        	\"POSNN\":\"\",\r\n" +
							"        	\"WERKS\":\"\",\r\n" +
							"        	\"MATNR\":\"\",\r\n" +
							"        	\"SCH_QTY\":\"\",\r\n" +
							"        	\"SCH_UOM\":\"\",\r\n" +
							"        	\"LOADING_KEY_NO1\":\"\",\r\n" +
							"        	\"LOADING_KEY_NO2\":\"\",\r\n" +
							"        	\"SEALING_NO\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/eai/disShippingCreateRan")
	public @ResponseBody
	Map<String, Object> disShippingCreateRan(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){

		String ZIFDAT = json_body.get("ZIFDAT").toString();
		String ZIFTIM = json_body.get("ZIFTIM").toString();
		String VEHICLE = json_body.get("VEHICLE").toString();
		String DRIVERCODE = json_body.get("DRIVERCODE").toString();

		String SHIPMENT_NO = json_body.get("SHIPMENT_NO").toString();
		String VBELN = json_body.get("VBELN").toString();
		String POSNN = json_body.get("POSNN").toString();
		String WERKS = json_body.get("WERKS").toString();
		String MATNR = json_body.get("MATNR").toString();
		String SCH_QTY = json_body.get("SCH_QTY").toString();
		String SCH_UOM = json_body.get("SCH_UOM").toString();
		String LOADING_KEY_NO1 = json_body.get("LOADING_KEY_NO1").toString();
		String LOADING_KEY_NO2 = json_body.get("LOADING_KEY_NO2").toString();
		String SEALING_NO = json_body.get("SEALING_NO").toString();

		HashMap[] hashMaps = new HashMap[1];
		hashMaps[0] = new HashMap();
		hashMaps[0].put("SHIPMENT_NO", SHIPMENT_NO);
		hashMaps[0].put("VBELN", VBELN);
		hashMaps[0].put("POSNN", POSNN);
		hashMaps[0].put("WERKS", WERKS);
		hashMaps[0].put("MATNR", MATNR);
		hashMaps[0].put("SCH_QTY", SCH_QTY);
		hashMaps[0].put("SCH_UOM", SCH_UOM);
		hashMaps[0].put("LOADING_KEY_NO1", LOADING_KEY_NO1);
		hashMaps[0].put("LOADING_KEY_NO2", LOADING_KEY_NO2);
		hashMaps[0].put("SEALING_NO", SEALING_NO);

		// 1.DIS_LOADING_REQUEST 테이블 삽입

		// 2.DIS_OPERATE_INFO 삽입 또는 업데이트

		// 3.EAI 서비스 호출
		return eaiService.disShippingCreateRan(ZIFDAT, ZIFTIM, VEHICLE, DRIVERCODE, hashMaps);
	}



	/**
	 * @param api_key
	 * *
	 @param json_body
	  * @return
	 */
	@ApiOperation(value="[EAI] 부피환산요청\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"MATNR\":\"\",\r\n" +
							"        	\"WERKS\":\"\",\r\n" +
							"        	\"GRS_QTY\":\"\",\r\n" +
							"        	\"GRS_UOM\":\"\",\r\n" +
							"        	\"TMP_VAL\":\"\",\r\n" +
							"        	\"TMP_UOM\":\"\",\r\n" +
							"        	\"DEN_VAL\":\"\",\r\n" +
							"        	\"NET_QTY\":\"\",\r\n" +
							"        	\"NET_UOM\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/eai/disVolumnExchangeCreate")
	public @ResponseBody
	Map<String, Object> disVolumnExchangeCreate(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){

		String MATNR = json_body.get("MATNR").toString();
		String WERKS = json_body.get("WERKS").toString();
		String GRS_QTY = json_body.get("GRS_QTY").toString();
		String GRS_UOM = json_body.get("GRS_UOM").toString();
		String TMP_VAL = json_body.get("TMP_VAL").toString();
		String TMP_UOM = json_body.get("TMP_UOM").toString();
		String DEN_VAL = json_body.get("DEN_VAL").toString();
		String NET_QTY = json_body.get("NET_QTY").toString();
		String NET_UOM = json_body.get("NET_UOM").toString();

		return eaiService.disVolumnExchangeCreate(
				MATNR, WERKS, GRS_QTY, GRS_UOM, TMP_VAL, TMP_UOM, DEN_VAL, NET_QTY, NET_UOM
		);
	}

	/**
	 * @param api_key
	 * *
	 @param json_body
	  * @return
	 */
	@ApiOperation(value="[EAI] 전자출하전표 조회(신규)\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"PLANT_CD\":\"2120\",\r\n" +
							"        	\"VEHICLE\":\"85-9999\",\r\n" +
							"        	\"ZFRDAT\":\"20200213\",\r\n" +
							"        	\"ZTODAT\":\"20200213\",\r\n" +
							"        	\"SHNUMBER\":\"\",\r\n" +
							"        	\"VBELN\":\"\",\r\n" +
							"        	\"POSNN\":\"\",\r\n" +
							"        	\"WERKS\":\"\",\r\n" +
							"        	\"LOAD_EDDTA\":\"\",\r\n" +
							"        	\"MATNR\":\"\",\r\n" +
							"        	\"GRS_QTY\":\"\",\r\n" +
							"        	\"GRS_UOM\":\"\",\r\n" +
							"        	\"NET_QTY\":\"\",\r\n" +
							"        	\"NET_UOM\":\"\",\r\n" +
							"        	\"TMP_VAL\":\"\",\r\n" +
							"        	\"TMP_UOM\":\"\",\r\n" +
							"        	\"DEN_VAL\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/eai/disLoadingTicketDisplay")
	public @ResponseBody
	Map<String, Object> disLoadingTicketDisplay(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){

		String plantCd = json_body.get("PLANT_CD").toString();
		String vehicleNo = json_body.get("VEHICLE").toString();
		String fromDate = json_body.get("ZFRDAT").toString();
		String toDate = json_body.get("ZTODAT").toString();
		String shnnumber = json_body.get("SHNNUMBER").toString();

		return eaiService.disLoadingTicketDisplay(vehicleNo, fromDate, toDate, shnnumber);
	}

}
