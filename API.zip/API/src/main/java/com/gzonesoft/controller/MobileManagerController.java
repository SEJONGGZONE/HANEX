package com.gzonesoft.controller;

import com.gzonesoft.service.MobileManagerService;
import com.gzonesoft.utils.SysUtils;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.security.NoSuchAlgorithmException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * http://localhost:9032/swagger-ui.html
 * @author ships
 *
 */
@RequestMapping("/api/manager")
@RestController
public class MobileManagerController {
    @Autowired private MobileManagerService mobileManagerService;

	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="업데이트체크\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_APP_CODE\":\"01\",\r\n" +
							"        	\"I_OS_TYPE\":\"01\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/appCheckManager")
	public @ResponseBody Map<String, Object> appCheckManager(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.appCheck(json_body);
	}

	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="로그인요청\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_ID\":\"gzone\",\r\n" +
							"        	\"I_PASS\":\"gzone\",\r\n" +
							"        	\"I_MIN_NO\":\"1076255736\",\r\n" +
							"        	\"I_APP_VERSION\":\"1.0.01\",\r\n" +
							"        	\"I_OS_VERSION\":\"Android SDK 30\",\r\n" +
							"        	\"I_UUID\":\"9924c149-596e-4d8f-a4ac-8980b51aba0f\",\r\n" +
							"        	\"I_DEVICE_MODEL\":\"SM-T575N\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/loginReq")
	public @ResponseBody Map<String, Object> loginReq(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body) throws NoSuchAlgorithmException {

		// 2022-10-11 수정(2가지 암호화값을 넣어준다)
		String orgString = json_body.get("I_PASS").toString();
		String encSHAString = SysUtils.encryptSHA256(orgString);
		String encMD5String = SysUtils.encryptMD5(orgString);
		json_body.put("I_PASS_SHA", encSHAString);
		json_body.put("I_PASS_MD5", encMD5String);

		return mobileManagerService.loginReq(json_body);
	}


	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="코드조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_CODE_TYPE\":\"\",\r\n" +
							"        	\"I_PARAM_01\":\"\",\r\n" +
							"        	\"I_PARAM_02\":\"\",\r\n" +
							"        	\"I_PARAM_03\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/codeSel")
	public @ResponseBody Map<String, Object> codeSel(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.codeSel(json_body);
	}

	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="최종작업상태조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_DRV_CD\":\"\",\r\n" +
							"        	\"I_VEHICLE_CD\":\"\",\r\n" +
							"        	\"I_MIN_NO\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/lastWorkSel")
	public @ResponseBody Map<String, Object> lastWorkSel(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.lastWorkSel(json_body);
	}

	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="현재위치 주변거래처 조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_PARAM_01\":\"37.636403\",\r\n" +
							"        	\"I_PARAM_02\":\"126.788301\",\r\n" +
							"        	\"I_PARAM_03\":\"10\",\r\n" +
							"        	\"I_PARAM_04\":\"\",\r\n" +
							"        	\"I_PARAM_05\":\"\"\r\n" +
							"        }\r\n" +
							"        -- 현재위치:(I_PARAM_01, I_PARAM_02)\n" +
							"        37.636403,126.788301\n" +
							"        -- 반경거리:(I_PARAM_03)\n" +
							"        10km",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/nearCustSearch")
	public @ResponseBody Map<String, Object> nearCustSearch(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.custSearch("NEAR_CUST", json_body);
	}

	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="현재위치 주변 담당거래처 조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_PARAM_01\":\"37.636403\",\r\n" +
							"        	\"I_PARAM_02\":\"126.788301\",\r\n" +
							"        	\"I_PARAM_03\":\"10\",\r\n" +
							"        	\"I_PARAM_04\":\"\",\r\n" +
							"        	\"I_PARAM_05\":\"\",\r\n" +
							"        	\"I_USER_ID\":\"211025\"\r\n" +
							"        }\r\n" +
							"        -- 현재위치:(I_PARAM_01, I_PARAM_02)\n" +
							"        37.636403,126.788301\n" +
							"        -- 반경거리:(I_PARAM_03)\n" +
							"        10km",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/nearCustUserSearch")
	public @ResponseBody Map<String, Object> nearCustUserSearch(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.custUserSearch("NEAR_CUST", json_body);
	}

	@ApiOperation(value="영역내 거래처조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_PARAM_01\":\"37.6544796\",\r\n" +
							"        	\"I_PARAM_02\":\"126.7707903\",\r\n" +
							"        	\"I_PARAM_03\":\"37.5722199\",\r\n" +
							"        	\"I_PARAM_04\":\"126.8408071\",\r\n" +
							"        	\"I_PARAM_05\":\"\"\r\n" +
							"        }\r\n" +
							"        -- 영역시작(좌상):(I_PARAM_01, I_PARAM_02)\n" +
							"        37.6544796,126.7707903\n" +
							"        -- 영역종료(우하):(I_PARAM_03, I_PARAM_04)\n" +
							"        37.5722199,126.8408071",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/areaCustSearch")
	public @ResponseBody Map<String, Object> areaCustSearch(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.custSearch("AREA_CUST", json_body);
	}

	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="영역내 담당 거래처조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_PARAM_01\":\"37.6544796\",\r\n" +
							"        	\"I_PARAM_02\":\"126.7707903\",\r\n" +
							"        	\"I_PARAM_03\":\"37.5722199\",\r\n" +
							"        	\"I_PARAM_04\":\"126.8408071\",\r\n" +
							"        	\"I_PARAM_05\":\"\",\r\n" +
							"        	\"I_USER_ID\":\"211025\"\r\n" +
							"        }\r\n" +
							"        -- 영역시작(좌상):(I_PARAM_01, I_PARAM_02)\n" +
							"        37.6544796,126.7707903\n" +
							"        -- 영역종료(우하):(I_PARAM_03, I_PARAM_04)\n" +
							"        37.5722199,126.8408071",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/areaCustUserSearch")
	public @ResponseBody Map<String, Object> areaCustUserSearch(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.custUserSearch("AREA_CUST", json_body);
	}

	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="현재위치 주문조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_DELI_REQ_DT\":\"20220209\",\r\n" +
							"        	\"I_FILTER_01\":\"\",\r\n" +
							"        	\"I_FILTER_02\":\"\",\r\n" +
							"        	\"I_FILTER_03\":\"\",\r\n" +
							"        	\"I_FILTER_04\":\"\",\r\n" +
							"        	\"I_FILTER_05\":\"\",\r\n" +
							"        	\"I_PARAM_01\":\"38.201172\",\r\n" +
							"        	\"I_PARAM_02\":\"126.463721\",\r\n" +
							"        	\"I_PARAM_03\":\"37.074124\",\r\n" +
							"        	\"I_PARAM_04\":\"127.307982\",\r\n" +
							"        	\"I_PARAM_05\":\"\"\r\n" +
							"        }\r\n" +
							"        -- 현재위치:(I_PARAM_01, I_PARAM_02)\n" +
							"        37.636403,126.788301\n" +
							"        -- 반경거리:(I_PARAM_03)\n" +
							"        10km",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/nearOrderSearch")
	public @ResponseBody Map<String, Object> nearOrderSearch(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body) {
		return mobileManagerService.orderSearch("NEAR_ORDER", json_body);
	}

	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="영역내 주문조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_DELI_REQ_DT\":\"20220109\",\r\n" +
							"        	\"I_FILTER_01\":\"\",\r\n" +
							"        	\"I_FILTER_02\":\"\",\r\n" +
							"        	\"I_FILTER_03\":\"\",\r\n" +
							"        	\"I_FILTER_04\":\"\",\r\n" +
							"        	\"I_FILTER_05\":\"\",\r\n" +
							"        	\"I_PARAM_01\":\"38.201172\",\r\n" +
							"        	\"I_PARAM_02\":\"126.463721\",\r\n" +
							"        	\"I_PARAM_03\":\"37.074124\",\r\n" +
							"        	\"I_PARAM_04\":\"127.307982\",\r\n" +
							"        	\"I_PARAM_05\":\"\"\r\n" +
							"        }\r\n" +
							"        -- 영역시작(좌상):(I_PARAM_01, I_PARAM_02)\n" +
							"        37.6544796,126.7707903\n" +
							"        -- 영역종료(우하):(I_PARAM_03, I_PARAM_04)\n" +
							"        37.5722199,126.8408071",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/areaOrderSearch")
	public @ResponseBody Map<String, Object> areaOrderSearch(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.orderSearch("AREA_ORDER", json_body);
	}

	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="영업/배차 주문 조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_TYPE\":\"영업\",\r\n" +
							"        	\"I_DELI_REQ_DT\":\"20221019\",\r\n" +
							"        	\"I_USER_ID\":\"211025\",\r\n" +
							"        	\"I_FILTER_01\":\"\",\r\n" +
							"        	\"I_FILTER_02\":\"\",\r\n" +
							"        	\"I_FILTER_03\":\"\",\r\n" +
							"        	\"I_FILTER_04\":\"\",\r\n" +
							"        	\"I_FILTER_05\":\"\",\r\n" +
							"        	\"I_PARAM_01\":\"38.201172\",\r\n" +
							"        	\"I_PARAM_02\":\"126.463721\",\r\n" +
							"        	\"I_PARAM_03\":\"37.074124\",\r\n" +
							"        	\"I_PARAM_04\":\"127.307982\",\r\n" +
							"        	\"I_PARAM_05\":\"\"\r\n" +
							"        }\r\n" +
							"        -- 영역시작(좌상):(I_PARAM_01, I_PARAM_02)\n" +
							"        37.6544796,126.7707903\n" +
							"        -- 영역종료(우하):(I_PARAM_03, I_PARAM_04)\n" +
							"        37.5722199,126.8408071",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/targetOrderSearch")
	public @ResponseBody Map<String, Object> targetOrderSearch(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.targetOrderSearch(json_body);
	}













	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="현재위치 차량조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_PARAM_01\":\"37.636403\",\r\n" +
							"        	\"I_PARAM_02\":\"126.788301\",\r\n" +
							"        	\"I_PARAM_03\":\"10\",\r\n" +
							"        	\"I_PARAM_04\":\"\",\r\n" +
							"        	\"I_PARAM_05\":\"\"\r\n" +
							"        }\r\n" +
							"        -- 현재위치:(I_PARAM_01, I_PARAM_02)\n" +
							"        37.636403,126.788301\n" +
							"        -- 반경거리:(I_PARAM_03)\n" +
							"        10km",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/nearVehicleSearch")
	public @ResponseBody Map<String, Object> nearVehicleSearch(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body) {
		return mobileManagerService.vehicleSearch("NEAR_VEHICLE", json_body);
	}

	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="영역내 차량조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_PARAM_01\":\"38.201172\",\r\n" +
							"        	\"I_PARAM_02\":\"126.463721\",\r\n" +
							"        	\"I_PARAM_03\":\"37.074124\",\r\n" +
							"        	\"I_PARAM_04\":\"127.307982\",\r\n" +
							"        	\"I_PARAM_05\":\"\"\r\n" +
							"        }\r\n" +
							"        -- 영역시작(좌상):(I_PARAM_01, I_PARAM_02)\n" +
							"        37.6544796,126.7707903\n" +
							"        -- 영역종료(우하):(I_PARAM_03, I_PARAM_04)\n" +
							"        37.5722199,126.8408071",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/areaVehicleSearch")
	public @ResponseBody Map<String, Object> areaVehicleSearch(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.vehicleSearch("AREA_VEHICLE", json_body);
	}

	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="영역내 지정차량조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_PARAM_01\":\"38.201172\",\r\n" +
							"        	\"I_PARAM_02\":\"126.463721\",\r\n" +
							"        	\"I_PARAM_03\":\"37.074124\",\r\n" +
							"        	\"I_PARAM_04\":\"127.307982\",\r\n" +
							"        	\"I_PARAM_05\":\"\",\r\n" +
							"        	\"I_VEHICLE_LIST\":\"\"\r\n" +
							"        }\r\n" +
							"        -- 영역시작(좌상):(I_PARAM_01, I_PARAM_02)\n" +
							"        37.6544796,126.7707903\n" +
							"        -- 영역종료(우하):(I_PARAM_03, I_PARAM_04)\n" +
							"        37.5722199,126.8408071",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/areaTargetVehicleSearch")
	public @ResponseBody Map<String, Object> areaTargetVehicleSearch(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.targetVehicleSearch("AREA_VEHICLE", json_body);
	}


	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="통합검색\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_KEYWORD\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/mainSearch")
	public @ResponseBody Map<String, Object> mainSearch(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.mainSearch(json_body);
	}


	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="설정조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_USER_ID\":\"gzone\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/userSettingSel")
	public @ResponseBody Map<String, Object> userSettingSel(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.userSettingSel(json_body);
	}


	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="설정저장\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_USER_ID\":\"gzone\",\r\n" +
							"        	\"I_SETTING_TYPE\":\"01\",\r\n" +
							"        	\"I_SETTING_DATA\":\"{'map_type':'01','zoom_level':'12'}\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/userSettingSav")
	public @ResponseBody Map<String, Object> userSettingSav(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.userSettingSav(json_body);
	}


	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="출하지 조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_STOCK_DT\":\"\",\r\n" +
							"        	\"I_PARAM_01\":\"\",\r\n" +
							"        	\"I_PARAM_02\":\"\",\r\n" +
							"        	\"I_PARAM_03\":\"\",\r\n" +
							"        	\"I_PARAM_04\":\"\",\r\n" +
							"        	\"I_PARAM_05\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/sourceSearch")
	public @ResponseBody Map<String, Object> sourceSearch(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.sourceSearch(json_body);
	}


	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="지정 출하지 조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_STOCK_DT\":\"\",\r\n" +
							"        	\"I_PARAM_01\":\"\",\r\n" +
							"        	\"I_PARAM_02\":\"\",\r\n" +
							"        	\"I_PARAM_03\":\"\",\r\n" +
							"        	\"I_PARAM_04\":\"\",\r\n" +
							"        	\"I_PARAM_05\":\"\",\r\n" +
							"        	\"I_SOURCE_LIST\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/targetSourceSearch")
	public @ResponseBody Map<String, Object> targetSourceSearch(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.targetSourceSearch(json_body);
	}

	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="경로상세 조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_TRACE_START_DTM\":\"20220529174022\",\r\n" +
							"        	\"I_TRACE_END_DTM\":\"20220529175110\",\r\n" +
							"        	\"I_MIN_NO\":\"01075935736\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/traceSearch")
	public @ResponseBody Map<String, Object> traceSearch(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.traceSearch(json_body);
	}



	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="출하지-재고조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_WERKS\":\"\",\r\n" +
							"        	\"I_PARAM_01\":\"\",\r\n" +
							"        	\"I_PARAM_02\":\"\",\r\n" +
							"        	\"I_PARAM_03\":\"\",\r\n" +
							"        	\"I_PARAM_04\":\"\",\r\n" +
							"        	\"I_PARAM_05\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/tankCapaSel")
	public @ResponseBody Map<String, Object> tankCapaSel(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.tankCapaSel(json_body);
	}



	/**
	 *
	 * @param api_key
	 * @param json_body
	 * @return
	 */
	@ApiOperation(value="저유소-재고 상세 조회\n")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "api_key", value = "API 키", required = true, dataType = "String", paramType = "header"),
			@ApiImplicitParam(name = "json_body",
					value =  "        {\r\n" +
							"        	\"I_DELI_REQ_DT\":\"\",\r\n" +
							"        	\"I_PARAM_01\":\"\",\r\n" +
							"        	\"I_PARAM_02\":\"\",\r\n" +
							"        	\"I_PARAM_03\":\"\",\r\n" +
							"        	\"I_PARAM_04\":\"\",\r\n" +
							"        	\"I_PARAM_05\":\"\"\r\n" +
							"        }",
					required = true, dataType = "object", paramType = "body")
	})
	@CrossOrigin("*")
	@PostMapping(value="/sourceStockSearch")
	public @ResponseBody Map<String, Object> sourceStockSearch(@RequestHeader String api_key, @RequestBody LinkedHashMap<String, Object> json_body){
		return mobileManagerService.sourceStockSearch(json_body);
	}
}
