const s="/assets/images/auth/user.png";export{s as _};
