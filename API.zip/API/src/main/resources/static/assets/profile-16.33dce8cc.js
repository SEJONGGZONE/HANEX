const s="/assets/images/profile-16.jpeg";export{s as _};
