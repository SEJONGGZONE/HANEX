import{a9 as Ce,r as V,b8 as Le,a0 as se,b9 as me,a8 as de,a1 as Ve,c as S,g as t,ba as Pe,bb as Re,R as ce,O as pe,aa as fe,d as ze,u as je,o as f,b as g,e,f as M,j as B,L as Y,y as T,G as w,H as R,D as $,Y as H,w as W,a5 as Te,X as ie}from"./index.2327c8d6.js";import{c as Oe,_ as X}from"./codePreview.3a0651de.js";import{S as qe}from"./sweetalert2.all.8d3c5acd.js";import{I as Ae}from"./icon-bell.a17e22c5.js";import{I as J}from"./icon-code.45f37684.js";function ve(r,o){var a=Object.keys(r);if(Object.getOwnPropertySymbols){var s=Object.getOwnPropertySymbols(r);o&&(s=s.filter(function(m){return Object.getOwnPropertyDescriptor(r,m).enumerable})),a.push.apply(a,s)}return a}function Z(r){for(var o=1;o<arguments.length;o++){var a=arguments[o]!=null?arguments[o]:{};o%2?ve(Object(a),!0).forEach(function(s){Ue(r,s,a[s])}):Object.getOwnPropertyDescriptors?Object.defineProperties(r,Object.getOwnPropertyDescriptors(a)):ve(Object(a)).forEach(function(s){Object.defineProperty(r,s,Object.getOwnPropertyDescriptor(a,s))})}return r}function Ue(r,o,a){return o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a,r}function be(r){let o=arguments.length>1&&arguments[1]!==void 0?arguments[1]:[];return Object.keys(r).reduce((a,s)=>(o.includes(s)||(a[s]=t(r[s])),a),{})}function oe(r){return typeof r=="function"}function Ge(r){return Pe(r)||Re(r)}function _e(r,o,a){let s=r;const m=o.split(".");for(let c=0;c<m.length;c++){if(!s[m[c]])return a;s=s[m[c]]}return s}function ne(r,o,a){return S(()=>r.some(s=>_e(o,s,{[a]:!1})[a]))}function $e(r,o,a){return S(()=>r.reduce((s,m)=>{const c=_e(o,m,{[a]:!1})[a]||[];return s.concat(c)},[]))}function Ne(r,o,a,s){return r.call(s,t(o),t(a),s)}function Fe(r){return r.$valid!==void 0?!r.$valid:!r}function Ze(r,o,a,s,m,c,N){let{$lazy:p,$rewardEarly:h}=m,u=arguments.length>7&&arguments[7]!==void 0?arguments[7]:[],F=arguments.length>8?arguments[8]:void 0,v=arguments.length>9?arguments[9]:void 0,E=arguments.length>10?arguments[10]:void 0;const x=V(!!s.value),l=V(0);a.value=!1;const b=se([o,s].concat(u,E),()=>{if(p&&!s.value||h&&!v.value&&!a.value)return;let d;try{d=Ne(r,o,F,N)}catch(C){d=Promise.reject(C)}l.value++,a.value=!!l.value,x.value=!1,Promise.resolve(d).then(C=>{l.value--,a.value=!!l.value,c.value=C,x.value=Fe(C)}).catch(C=>{l.value--,a.value=!!l.value,c.value=C,x.value=!0})},{immediate:!0,deep:typeof o=="object"});return{$invalid:x,$unwatch:b}}function Ie(r,o,a,s,m,c,N,p){let{$lazy:h,$rewardEarly:u}=s;const F=()=>({}),v=S(()=>{if(h&&!a.value||u&&!p.value)return!1;let E=!0;try{const x=Ne(r,o,N,c);m.value=x,E=Fe(x)}catch(x){m.value=x}return E});return{$unwatch:F,$invalid:v}}function Me(r,o,a,s,m,c,N,p,h,u,F){const v=V(!1),E=r.$params||{},x=V(null);let l,b;r.$async?{$invalid:l,$unwatch:b}=Ze(r.$validator,o,v,a,s,x,m,r.$watchTargets,h,u,F):{$invalid:l,$unwatch:b}=Ie(r.$validator,o,a,s,x,m,h,u);const d=r.$message;return{$message:oe(d)?S(()=>d(be({$pending:v,$invalid:l,$params:be(E),$model:o,$response:x,$validator:c,$propertyPath:p,$property:N}))):d||"",$params:E,$pending:v,$invalid:l,$response:x,$unwatch:b}}function De(){let r=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};const o=t(r),a=Object.keys(o),s={},m={},c={};let N=null;return a.forEach(p=>{const h=o[p];switch(!0){case oe(h.$validator):s[p]=h;break;case oe(h):s[p]={$validator:h};break;case p==="$validationGroups":N=h;break;case p.startsWith("$"):c[p]=h;break;default:m[p]=h}}),{rules:s,nestedValidators:m,config:c,validationGroups:N}}const Be="__root";function Ye(r,o,a,s,m,c,N,p,h){const u=Object.keys(r),F=s.get(m,r),v=V(!1),E=V(!1),x=V(0);if(F){if(!F.$partial)return F;F.$unwatch(),v.value=F.$dirty.value}const l={$dirty:v,$path:m,$touch:()=>{v.value||(v.value=!0)},$reset:()=>{v.value&&(v.value=!1)},$commit:()=>{}};return u.length?(u.forEach(b=>{l[b]=Me(r[b],o,l.$dirty,c,N,b,a,m,h,E,x)}),l.$externalResults=S(()=>p.value?[].concat(p.value).map((b,d)=>({$propertyPath:m,$property:a,$validator:"$externalResults",$uid:`${m}-externalResult-${d}`,$message:b,$params:{},$response:null,$pending:!1})):[]),l.$invalid=S(()=>{const b=u.some(d=>t(l[d].$invalid));return E.value=b,!!l.$externalResults.value.length||b}),l.$pending=S(()=>u.some(b=>t(l[b].$pending))),l.$error=S(()=>l.$dirty.value?l.$pending.value||l.$invalid.value:!1),l.$silentErrors=S(()=>u.filter(b=>t(l[b].$invalid)).map(b=>{const d=l[b];return de({$propertyPath:m,$property:a,$validator:b,$uid:`${m}-${b}`,$message:d.$message,$params:d.$params,$response:d.$response,$pending:d.$pending})}).concat(l.$externalResults.value)),l.$errors=S(()=>l.$dirty.value?l.$silentErrors.value:[]),l.$unwatch=()=>u.forEach(b=>{l[b].$unwatch()}),l.$commit=()=>{E.value=!0,x.value=Date.now()},s.set(m,r,l),l):(F&&s.set(m,r,l),l)}function He(r,o,a,s,m,c,N){const p=Object.keys(r);return p.length?p.reduce((h,u)=>(h[u]=ue({validations:r[u],state:o,key:u,parentKey:a,resultsCache:s,globalConfig:m,instance:c,externalResults:N}),h),{}):{}}function We(r,o,a){const s=S(()=>[o,a].filter(l=>l).reduce((l,b)=>l.concat(Object.values(t(b))),[])),m=S({get(){return r.$dirty.value||(s.value.length?s.value.every(l=>l.$dirty):!1)},set(l){r.$dirty.value=l}}),c=S(()=>{const l=t(r.$silentErrors)||[],b=s.value.filter(d=>(t(d).$silentErrors||[]).length).reduce((d,C)=>d.concat(...C.$silentErrors),[]);return l.concat(b)}),N=S(()=>{const l=t(r.$errors)||[],b=s.value.filter(d=>(t(d).$errors||[]).length).reduce((d,C)=>d.concat(...C.$errors),[]);return l.concat(b)}),p=S(()=>s.value.some(l=>l.$invalid)||t(r.$invalid)||!1),h=S(()=>s.value.some(l=>t(l.$pending))||t(r.$pending)||!1),u=S(()=>s.value.some(l=>l.$dirty)||s.value.some(l=>l.$anyDirty)||m.value),F=S(()=>m.value?h.value||p.value:!1),v=()=>{r.$touch(),s.value.forEach(l=>{l.$touch()})},E=()=>{r.$commit(),s.value.forEach(l=>{l.$commit()})},x=()=>{r.$reset(),s.value.forEach(l=>{l.$reset()})};return s.value.length&&s.value.every(l=>l.$dirty)&&v(),{$dirty:m,$errors:N,$invalid:p,$anyDirty:u,$error:F,$pending:h,$touch:v,$reset:x,$silentErrors:c,$commit:E}}function ue(r){let{validations:o,state:a,key:s,parentKey:m,childResults:c,resultsCache:N,globalConfig:p={},instance:h,externalResults:u}=r;const F=m?`${m}.${s}`:s,{rules:v,nestedValidators:E,config:x,validationGroups:l}=De(o),b=Z(Z({},p),x),d=s?S(()=>{const P=t(a);return P?t(P[s]):void 0}):a,C=Z({},t(u)||{}),z=S(()=>{const P=t(u);return s?P?t(P[s]):void 0:P}),k=Ye(v,d,s,N,F,b,h,z,a),A=He(E,d,F,N,b,h,z),_={};l&&Object.entries(l).forEach(P=>{let[I,G]=P;_[I]={$invalid:ne(G,A,"$invalid"),$error:ne(G,A,"$error"),$pending:ne(G,A,"$pending"),$errors:$e(G,A,"$errors"),$silentErrors:$e(G,A,"$silentErrors")}});const{$dirty:K,$errors:O,$invalid:Q,$anyDirty:j,$error:L,$pending:ee,$touch:y,$reset:le,$silentErrors:U,$commit:te}=We(k,A,c),i=s?S({get:()=>t(d),set:P=>{K.value=!0;const I=t(a),G=t(u);G&&(G[s]=C[s]),me(I[s])?I[s].value=P:I[s]=P}}):null;s&&b.$autoDirty&&se(d,()=>{K.value||y();const P=t(u);P&&(P[s]=C[s])},{flush:"sync"});async function n(){return y(),b.$rewardEarly&&(te(),await fe()),await fe(),new Promise(P=>{if(!ee.value)return P(!Q.value);const I=se(ee,()=>{P(!Q.value),I()})})}function Se(P){return(c.value||{})[P]}function Ee(){me(u)?u.value=C:Object.keys(C).length===0?Object.keys(u).forEach(P=>{delete u[P]}):Object.assign(u,C)}return de(Z(Z(Z({},k),{},{$model:i,$dirty:K,$error:L,$errors:O,$invalid:Q,$anyDirty:j,$pending:ee,$touch:y,$reset:le,$path:F||Be,$silentErrors:U,$validate:n,$commit:te},c&&{$getResultsForChild:Se,$clearExternalResults:Ee,$validationGroups:_}),A))}class Xe{constructor(){this.storage=new Map}set(o,a,s){this.storage.set(o,{rules:a,result:s})}checkRulesValidity(o,a,s){const m=Object.keys(s),c=Object.keys(a);return c.length!==m.length||!c.every(p=>m.includes(p))?!1:c.every(p=>a[p].$params?Object.keys(a[p].$params).every(h=>t(s[p].$params[h])===t(a[p].$params[h])):!0)}get(o,a){const s=this.storage.get(o);if(!s)return;const{rules:m,result:c}=s,N=this.checkRulesValidity(o,a,m),p=c.$unwatch?c.$unwatch:()=>({});return N?c:{$dirty:c.$dirty,$partial:!0,$unwatch:p}}}const ae={COLLECT_ALL:!0,COLLECT_NONE:!1},he=Symbol("vuelidate#injectChildResults"),ye=Symbol("vuelidate#removeChildResults");function Je(r){let{$scope:o,instance:a}=r;const s={},m=V([]),c=S(()=>m.value.reduce((F,v)=>(F[v]=t(s[v]),F),{}));function N(F,v){let{$registerAs:E,$scope:x,$stopPropagation:l}=v;l||o===ae.COLLECT_NONE||x===ae.COLLECT_NONE||o!==ae.COLLECT_ALL&&o!==x||(s[E]=F,m.value.push(E))}a.__vuelidateInjectInstances=[].concat(a.__vuelidateInjectInstances||[],N);function p(F){m.value=m.value.filter(v=>v!==F),delete s[F]}a.__vuelidateRemoveInstances=[].concat(a.__vuelidateRemoveInstances||[],p);const h=ce(he,[]);pe(he,a.__vuelidateInjectInstances);const u=ce(ye,[]);return pe(ye,a.__vuelidateRemoveInstances),{childResults:c,sendValidationResultsToParent:h,removeValidationResultsFromParent:u}}function ke(r){return new Proxy(r,{get(o,a){return typeof o[a]=="object"?ke(o[a]):S(()=>o[a])}})}let ge=0;function re(r,o){var a;let s=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{};arguments.length===1&&(s=r,r=void 0,o=void 0);let{$registerAs:m,$scope:c=ae.COLLECT_ALL,$stopPropagation:N,$externalResults:p,currentVueInstance:h}=s;const u=h||((a=Ce())===null||a===void 0?void 0:a.proxy),F=u?u.$options:{};m||(ge+=1,m=`_vuelidate_${ge}`);const v=V({}),E=new Xe,{childResults:x,sendValidationResultsToParent:l,removeValidationResultsFromParent:b}=u?Je({$scope:c,instance:u}):{childResults:V({})};if(!r&&F.validations){const d=F.validations;o=V({}),Le(()=>{o.value=u,se(()=>oe(d)?d.call(o.value,new ke(o.value)):d,C=>{v.value=ue({validations:C,state:o,childResults:x,resultsCache:E,globalConfig:s,instance:u,externalResults:p||u.vuelidateExternalResults})},{immediate:!0})}),s=F.validationsConfig||s}else{const d=me(r)||Ge(r)?r:de(r||{});se(d,C=>{v.value=ue({validations:C,state:o,childResults:x,resultsCache:E,globalConfig:s,instance:u!=null?u:{},externalResults:p})},{immediate:!0})}return u&&(l.forEach(d=>d(v,{$registerAs:m,$scope:c,$stopPropagation:N})),Ve(()=>b.forEach(d=>d(m)))),S(()=>Z(Z({},t(v.value)),x.value))}const we=r=>{if(r=t(r),Array.isArray(r))return!!r.length;if(r==null)return!1;if(r===!1)return!0;if(r instanceof Date)return!isNaN(r.getTime());if(typeof r=="object"){for(let o in r)return!0;return!1}return!!String(r).length};function D(){for(var r=arguments.length,o=new Array(r),a=0;a<r;a++)o[a]=arguments[a];return s=>(s=t(s),!we(s)||o.every(m=>(m.lastIndex=0,m.test(s))))}D(/^[a-zA-Z]*$/);D(/^[a-zA-Z0-9]*$/);D(/^\d*(\.\d+)?$/);const Ke=/^(?:[A-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[A-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9]{2,}(?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])$/i;var Qe=D(Ke),et={$validator:Qe,$message:"Value is not a valid email address",$params:{type:"email"}};function tt(r){return typeof r=="string"&&(r=r.trim()),we(r)}var q={$validator:tt,$message:"Value is required",$params:{type:"required"}};function rt(r){return o=>t(o)===t(r)}function xe(r){let o=arguments.length>1&&arguments[1]!==void 0?arguments[1]:"other";return{$validator:rt(r),$message:a=>`The value must be equal to the ${o} value`,$params:{equalTo:r,otherName:o,type:"sameAs"}}}const st=/^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z0-9\u00a1-\uffff][a-z0-9\u00a1-\uffff_-]{0,62})?[a-z0-9\u00a1-\uffff]\.)+(?:[a-z\u00a1-\uffff]{2,}\.?))(?::\d{2,5})?(?:[/?#]\S*)?$/i;D(st);D(/(^[0-9]*$)|(^-[0-9]+$)/);D(/^[-]?\d*(\.\d+)?$/);const at=e("ul",{class:"flex space-x-2 rtl:space-x-reverse"},[e("li",null,[e("a",{href:"javascript:;",class:"text-primary hover:underline"},"Forms")]),e("li",{class:"before:content-['/'] ltr:before:mr-2 rtl:before:ml-2"},[e("span",null,"Validation")])],-1),ot={class:"pt-5 space-y-8"},lt={class:"panel p-3 flex items-center text-primary overflow-x-auto whitespace-nowrap"},it={class:"ring-2 ring-primary/30 rounded-full bg-primary text-white p-1.5 ltr:mr-3 rtl:ml-3"},nt=e("span",{class:"ltr:mr-3 rtl:ml-3"},"Documentation: ",-1),mt=e("a",{href:"https://www.npmjs.com/package/vuelidate",target:"_blank",class:"block hover:underline"},"https://www.npmjs.com/package/vuelidate",-1),ut={class:"grid grid-cols-1 xl:grid-cols-2 gap-6"},dt={class:"panel"},ct={class:"flex items-center justify-between mb-5"},pt=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Basic",-1),ft={class:"flex items-center"},vt={class:"mb-5"},bt=e("label",{for:"fullName"},"Full Name",-1),$t={key:0,class:"text-[#1abc9c] mt-1"},ht={key:1,class:"text-danger mt-1"},yt=e("button",{type:"submit",class:"btn btn-primary !mt-6"},"Submit Form",-1),gt=e("pre",null,`<!-- basic -->
<form class="space-y-5" @submit.prevent="submitForm1()">
  <div :class="{ 'has-error': $v1.form1.name.$error, 'has-success': isSubmitForm1 && !$v1.form1.name.$error }">
    <label for="fullName">Full Name</label>
    <input id="fullName" type="text" placeholder="Enter Full Name" class="form-input" v-model="form1.name" />
    <template v-if="isSubmitForm1 && !$v1.form1.name.$error">
      <p class="text-[#1abc9c] mt-1">Looks Good!</p>
    </template>
    <template v-if="isSubmitForm1 && $v1.form1.name.$error">
      <p class="text-danger mt-1">Please fill the Name</p>
    </template>
  </div>
  <button type="submit" class="btn btn-primary !mt-6">Submit Form</button>
</form>

<!-- script -->
<script lang="ts" setup>
  import { ref } from 'vue';
  import { useVuelidate } from '@vuelidate/core';
  import { required, email, sameAs } from '@vuelidate/validators';
  const form1 = ref({
    name: '',
  });
  const isSubmitForm1 = ref(false);
  const rules1 = {
    form1: {
      name: { required },
    },
  };
  const $v1 = useVuelidate(rules1, { form1 });
  const submitForm1 = () => {
    isSubmitForm1.value = true;
    $v1.value.form1.$touch();
    if ($v1.value.form1.$invalid) {
      return false;
    }
    //form validated success
    showMessage('Form submitted successfully.');
  };
<\/script>
`,-1),xt={class:"panel"},_t={class:"flex items-center justify-between mb-5"},Nt=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Email",-1),Ft={class:"flex items-center"},kt={class:"mb-5"},wt=e("label",{for:"Email"},"Email",-1),St={key:0,class:"text-[#1abc9c] mt-1"},Et={key:1,class:"text-danger mt-1"},Ct=e("button",{type:"submit",class:"btn btn-primary !mt-6"},"Submit Form",-1),Lt=e("pre",null,`<!-- email -->
<form class="space-y-5" @submit.prevent="submitForm2()">
  <div :class="{ 'has-error': $v2.form2.email.$error, 'has-success': isSubmitForm2 && !$v2.form2.email.$error }">
    <label for="Email">Email</label>
    <input id="Email" type="text" placeholder="Enter Email" class="form-input" v-model="form2.email" />
    <template v-if="isSubmitForm2 && !$v2.form2.email.$error">
      <p class="text-[#1abc9c] mt-1">Looks Good!</p>
    </template>
    <template v-if="isSubmitForm2 && $v2.form2.email.$error">
      <p class="text-danger mt-1">Please fill the Email</p>
    </template>
  </div>
  <button type="submit" class="btn btn-primary !mt-6">Submit Form</button>
</form>

<!-- script -->
<script lang="ts" setup>
  import { ref } from 'vue';
  import { useVuelidate } from '@vuelidate/core';
  import { required, email, sameAs } from '@vuelidate/validators';

  const form2 = ref({
    email: '',
  });
  const isSubmitForm2 = ref(false);
  const rules2 = {
    form2: {
      email: { required, email },
    },
  };
  const $v2 = useVuelidate(rules2, { form2 });
  const submitForm2 = () => {
    isSubmitForm2.value = true;
    $v2.value.form2.$touch();
    if ($v2.value.form2.$invalid) {
      return false;
    }
    //form validated success
    showMessage('Form submitted successfully.');
  };
<\/script>
`,-1),Vt={class:"panel"},Pt={class:"flex items-center justify-between mb-5"},Rt=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Select",-1),zt={class:"flex items-center"},jt={class:"mb-5"},Tt=e("option",{value:""},"Open this select menu",-1),Ot=e("option",{value:"1"},"One",-1),qt=e("option",{value:"2"},"Two",-1),At=e("option",{value:"3"},"Three",-1),Ut=[Tt,Ot,qt,At],Gt={key:0,class:"text-[#1abc9c] mt-1"},Zt={key:1,class:"text-danger mt-1"},It=e("button",{type:"submit",class:"btn btn-primary !mt-6"},"Submit Form",-1),Mt=e("pre",null,`<!-- select -->
<form class="space-y-5" @submit.prevent="submitForm3()">
  <div :class="{ 'has-error': $v3.form3.select.$error, 'has-success': isSubmitForm3 && !$v3.form3.select.$error }">
    <select class="form-select text-white-dark" v-model="form3.select">
      <option value="">Open this select menu</option>
      <option value="1">One</option>
      <option value="2">Two</option>
      <option value="3">Three</option>
    </select>
    <template v-if="isSubmitForm3 && !$v3.form3.select.$error">
      <p class="text-[#1abc9c] mt-1">Example valid custom select feedback</p>
    </template>
    <template v-if="isSubmitForm3 && $v3.form3.select.$error">
      <p class="text-danger mt-1">Please Select the field</p>
    </template>
  </div>
  <button type="submit" class="btn btn-primary !mt-6">Submit Form</button>
</form>

<!-- script -->
<script lang="ts" setup>
  import { ref } from 'vue';
  import { useVuelidate } from '@vuelidate/core';
  import { required, email, sameAs } from '@vuelidate/validators';

  const form3 = ref({
    select: '',
  });
  const isSubmitForm3 = ref(false);
  const rules3 = {
    form3: {
      select: { required },
    },
  };
  const $v3 = useVuelidate(rules3, { form3 });
  const submitForm3 = () => {
    isSubmitForm3.value = true;
    $v3.value.form3.$touch();
    if ($v3.value.form3.$invalid) {
      return false;
    }
    //form validated success
    showMessage('Form submitted successfully.');
  };
<\/script>
`,-1),Dt={class:"panel"},Bt={class:"flex items-center justify-between mb-5"},Yt=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Custom Styles",-1),Ht={class:"flex items-center"},Wt={class:"mb-5"},Xt={class:"grid grid-cols-1 md:grid-cols-3 gap-5"},Jt=e("label",{for:"customFname"},"First Name",-1),Kt={key:0,class:"text-[#1abc9c] mt-1"},Qt={key:1,class:"text-danger mt-1"},er=e("label",{for:"customLname"},"Last name",-1),tr={key:0,class:"text-[#1abc9c] mt-1"},rr={key:1,class:"text-danger mt-1"},sr=e("label",{for:"customeEmail"},"Username",-1),ar={class:"flex"},or=e("div",{class:"bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"}," @ ",-1),lr={key:0,class:"text-[#1abc9c] mt-1"},ir={key:1,class:"text-danger mt-1"},nr={class:"grid grid-cols-1 md:grid-cols-4 gap-5"},mr=e("label",{for:"customeCity"},"City",-1),ur={key:0,class:"text-[#1abc9c] mt-1"},dr={key:1,class:"text-danger mt-1"},cr=e("label",{for:"customeState"},"State",-1),pr={key:0,class:"text-[#1abc9c] mt-1"},fr={key:1,class:"text-danger mt-1"},vr=e("label",{for:"customeZip"},"Zip",-1),br={key:0,class:"text-[#1abc9c] mt-1"},$r={key:1,class:"text-danger mt-1"},hr={class:"inline-flex cursor-pointer mt-1"},yr=e("span",{class:"text-white-dark"},"Agree to terms and conditions",-1),gr={key:0,class:"text-danger mt-1"},xr=e("button",{type:"submit",class:"btn btn-primary !mt-6"},"Submit Form",-1),_r=e("pre",null,`<!-- custom styles -->
<form class="space-y-5" @submit.prevent="submitForm4()">
  <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
    <div :class="{ 'has-error': $v4.form4.firstName.$error, 'has-success': isSubmitForm4 && !$v4.form4.firstName.$error }">
      <label for="customFname">First Name</label>
      <input id="customFname" type="text" placeholder="Enter First Name" class="form-input" v-model="form4.firstName" />
      <template v-if="isSubmitForm4 && !$v4.form4.firstName.$error">
        <p class="text-[#1abc9c] mt-1">Looks Good!</p>
      </template>
      <template v-if="isSubmitForm4 && $v4.form4.firstName.$error">
        <p class="text-danger mt-1">Please fill the first name</p>
      </template>
    </div>
    <div :class="{ 'has-error': $v4.form4.lastName.$error, 'has-success': isSubmitForm4 && !$v4.form4.lastName.$error }">
      <label for="customLname">Last name</label>
      <input id="customLname" type="text" placeholder="Enter Last Name" class="form-input" v-model="form4.lastName" />
      <template v-if="isSubmitForm4 && !$v4.form4.lastName.$error">
        <p class="text-[#1abc9c] mt-1">Looks Good!</p>
      </template>
      <template v-if="isSubmitForm4 && $v4.form4.lastName.$error">
        <p class="text-danger mt-1">Please fill the last name</p>
      </template>
    </div>
    <div :class="{ 'has-error': $v4.form4.userName.$error, 'has-success': isSubmitForm4 && !$v4.form4.userName.$error }">
      <label for="customeEmail">Username</label>
      <div class="flex">
        <div
          class="
            bg-[#eee]
            flex
            justify-center
            items-center
            ltr:rounded-l-md
            rtl:rounded-r-md
            px-3
            font-semibold
            border
            ltr:border-r-0
            rtl:border-l-0
            border-[#e0e6ed]
            dark:border-[#17263c] dark:bg-[#1b2e4b]
          "
        >
          @
        </div>
        <input id="customeEmail" type="text" placeholder="Enter Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none" v-model="form4.userName" />
      </div>
      <template v-if="isSubmitForm4 && !$v4.form4.userName.$error">
        <p class="text-[#1abc9c] mt-1">Looks Good!</p>
      </template>
      <template v-if="isSubmitForm4 && $v4.form4.userName.$error">
        <p class="text-danger mt-1">Please choose a userName</p>
      </template>
    </div>
  </div>
  <div class="grid grid-cols-1 md:grid-cols-4 gap-5">
    <div class="md:col-span-2" :class="{ 'has-error': $v4.form4.city.$error, 'has-success': isSubmitForm4 && !$v4.form4.city.$error }">
      <label for="customeCity">City</label>
      <input id="customeCity" type="text" placeholder="Enter City" class="form-input" v-model="form4.city" />
      <template v-if="isSubmitForm4 && !$v4.form4.city.$error">
        <p class="text-[#1abc9c] mt-1">Looks Good!</p>
      </template>
      <template v-if="isSubmitForm4 && $v4.form4.city.$error">
        <p class="text-danger mt-1">Please provide a valid city</p>
      </template>
    </div>
    <div :class="{ 'has-error': $v4.form4.state.$error, 'has-success': isSubmitForm4 && !$v4.form4.state.$error }">
      <label for="customeState">State</label>
      <input id="customeState" type="text" placeholder="Enter State" class="form-input" v-model="form4.state" />
      <template v-if="isSubmitForm4 && !$v4.form4.state.$error">
        <p class="text-[#1abc9c] mt-1">Looks Good!</p>
      </template>
      <template v-if="isSubmitForm4 && $v4.form4.state.$error">
        <p class="text-danger mt-1">Please provide a valid state</p>
      </template>
    </div>
    <div :class="{ 'has-error': $v4.form4.zip.$error, 'has-success': isSubmitForm4 && !$v4.form4.zip.$error }">
      <label for="customeZip">Zip</label>
      <input id="customeZip" type="text" placeholder="Enter Zip" class="form-input" v-model="form4.zip" />
      <template v-if="isSubmitForm4 && !$v4.form4.zip.$error">
        <p class="text-[#1abc9c] mt-1">Looks Good!</p>
      </template>
      <template v-if="isSubmitForm4 && $v4.form4.zip.$error">
        <p class="text-danger mt-1">Please provide a valid zip</p>
      </template>
    </div>
  </div>
  <div :class="{ 'has-error': $v4.form4.isTerms.$error, 'has-success': isSubmitForm4 && !$v4.form4.isTerms.$error }">
    <label class="inline-flex cursor-pointer mt-1">
      <input type="checkbox" class="form-checkbox" v-model="form4.isTerms" />
      <span class="text-white-dark">Agree to terms and conditions</span>
    </label>
    <template v-if="isSubmitForm4 && $v4.form4.isTerms.$error">
      <p class="text-danger mt-1">You must agree before submitting.</p>
    </template>
  </div>
  <button type="submit" class="btn btn-primary !mt-6">Submit Form</button>
</form>

<!-- script -->
<script lang="ts" setup>
  import { ref } from 'vue';
  import { useVuelidate } from '@vuelidate/core';
  import { required, email, sameAs } from '@vuelidate/validators';

  const form4 = ref({
    firstName: 'Shaun',
    lastName: 'Park',
    userName: '',
    city: '',
    state: '',
    zip: '',
    isTerms: false,
  });
  const isSubmitForm4 = ref(false);
  const rules4 = {
    form4: {
      firstName: { required },
      lastName: { required },
      userName: { required },
      city: { required },
      state: { required },
      zip: { required },
      isTerms: {
        sameAsRawValue: sameAs(true),
      },
    },
  };
  const $v4 = useVuelidate(rules4, { form4 });
  const submitForm4 = () => {
    isSubmitForm4.value = true;
    $v4.value.form4.$touch();
    if ($v4.value.form4.$invalid) {
      return false;
    }
    //form validated success
    showMessage('Form submitted successfully.');
  };

<\/script>
`,-1),Nr={class:"panel"},Fr={class:"flex items-center justify-between mb-5"},kr=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Browser Default",-1),wr={class:"flex items-center"},Sr={class:"mb-5"},Er={class:"grid grid-cols-1 md:grid-cols-3 gap-5"},Cr=e("label",{for:"browserFname"},"First Name",-1),Lr=e("label",{for:"browserLname"},"Last name",-1),Vr=e("label",{for:"browserEmail"},"Username",-1),Pr={class:"flex"},Rr=e("div",{class:"bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"}," @ ",-1),zr={class:"grid grid-cols-1 md:grid-cols-4 gap-5"},jr={class:"md:col-span-2"},Tr=e("label",{for:"browserCity"},"City",-1),Or=e("label",{for:"browserState"},"State",-1),qr=e("label",{for:"browserZip"},"Zip",-1),Ar={class:"flex items-center cursor-pointer mt-1"},Ur=e("span",{class:"text-white-dark"},"Agree to terms and conditions",-1),Gr=e("button",{type:"submit",class:"btn btn-primary !mt-6"},"Submit Form",-1),Zr=e("pre",null,`<!-- browser default -->
<form class="space-y-5" @submit.prevent="submitForm5()">
  <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
    <div>
      <label for="browserFname">First Name</label>
      <input id="browserFname" type="text" placeholder="Enter First Name" v-model="form5.firstName" class="form-input" required />
    </div>
    <div>
      <label for="browserLname">Last name</label>
      <input id="browserLname" type="text" placeholder="Enter Last name" v-model="form5.lastName" class="form-input" required />
    </div>
    <div>
      <label for="browserEmail">Username</label>
      <div class="flex">
        <div
          class="
            bg-[#eee]
            flex
            justify-center
            items-center
            ltr:rounded-l-md
            rtl:rounded-r-md
            px-3
            font-semibold
            border
            ltr:border-r-0
            rtl:border-l-0
            border-[#e0e6ed]
            dark:border-[#17263c] dark:bg-[#1b2e4b]
          "
        >
          @
        </div>
        <input id="browserEmail" type="text" placeholder="Enter Username" v-model="form5.userName" class="form-input ltr:rounded-l-none rtl:rounded-r-none" required />
      </div>
    </div>
  </div>
  <div class="grid grid-cols-1 md:grid-cols-4 gap-5">
    <div class="md:col-span-2">
      <label for="browserCity">City</label>
      <input id="browserCity" type="text" placeholder="Enter City" v-model="form5.city" class="form-input" required />
    </div>
    <div>
      <label for="browserState">State</label>
      <input id="browserState" type="text" placeholder="Enter State" v-model="form5.state" class="form-input" required />
    </div>
    <div>
      <label for="browserZip">Zip</label>
      <input id="browserZip" type="text" placeholder="Enter Zip" v-model="form5.zip" class="form-input" required />
    </div>
  </div>
  <div>
    <label class="flex items-center cursor-pointer mt-1">
      <input type="checkbox" class="form-checkbox" v-model="form5.isTerms" required />
      <span class="text-white-dark">Agree to terms and conditions</span>
    </label>
  </div>
  <button type="submit" class="btn btn-primary !mt-6">Submit Form</button>
</form>

<!-- script -->
<script lang="ts" setup>
  import { ref } from 'vue';
  import { useVuelidate } from '@vuelidate/core';
  import { required, email, sameAs } from '@vuelidate/validators';

  const form5 = ref({
    firstName: 'Shaun',
    lastName: 'Park',
    userName: '',
    city: '',
    state: '',
    zip: '',
    isTerms: false,
  });
  const submitForm5 = () => {
    //form validated success
    showMessage('Form submitted successfully.');
  };
<\/script>
`,-1),Ir={class:"panel"},Mr={class:"flex items-center justify-between mb-5"},Dr=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Tooltips",-1),Br={class:"flex items-center"},Yr={class:"mb-5"},Hr={class:"grid grid-cols-1 md:grid-cols-3 gap-5"},Wr=e("label",{for:"tlpFname"},"First Name",-1),Xr={key:0,class:"text-white bg-[#1abc9c] py-1 px-2 rounded"},Jr={key:1,class:"text-white bg-danger py-1 px-2 rounded"},Kr=e("label",{for:"tlpLname"},"Last name",-1),Qr={key:0,class:"text-white bg-[#1abc9c] py-1 px-2 rounded"},es={key:1,class:"text-white bg-danger py-1 px-2 rounded"},ts=e("label",{for:"tlpEmail"},"Username",-1),rs={class:"flex"},ss=e("div",{class:"bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"}," @ ",-1),as={class:"mt-2"},os={key:0,class:"text-white bg-[#1abc9c] py-1 px-2 rounded"},ls={key:1,class:"text-white bg-danger py-1 px-2 rounded"},is={class:"grid grid-cols-1 md:grid-cols-4 gap-5"},ns=e("label",{for:"tlpCity"},"City",-1),ms={key:0,class:"text-white bg-[#1abc9c] py-1 px-2 rounded"},us={key:1,class:"text-white bg-danger py-1 px-2 rounded"},ds=e("label",{for:"tlpState"},"State",-1),cs={key:0,class:"text-white bg-[#1abc9c] py-1 px-2 rounded"},ps={key:1,class:"text-white bg-danger py-1 px-2 rounded"},fs=e("label",{for:"tlpZip"},"Zip",-1),vs={key:0,class:"text-white bg-[#1abc9c] py-1 px-2 rounded"},bs={key:1,class:"text-white bg-danger py-1 px-2 rounded"},$s={class:"flex items-center cursor-pointer"},hs=e("span",{class:"text-white-dark"},"Agree to terms and conditions",-1),ys={key:0,class:"mt-2"},gs=e("span",{class:"text-white bg-danger py-1 px-2 rounded"},"You must agree before submitting.",-1),xs=[gs],_s=e("button",{type:"submit",class:"btn btn-primary !mt-6"},"Submit Form",-1),Ns=e("pre",null,`<!-- tooltips -->
<form class="space-y-5" @submit.prevent="submitForm6()">
  <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
    <div :class="{ 'has-error': $v6.form6.firstName.$error, 'has-success': isSubmitForm6 && !$v6.form6.firstName.$error }">
      <label for="tlpFname">First Name</label>
      <input id="tlpFname" type="text" placeholder="Enter First Name" class="form-input mb-2" v-model="form6.firstName" />
      <template v-if="isSubmitForm6 && !$v6.form6.firstName.$error">
        <span class="text-white bg-[#1abc9c] py-1 px-2 rounded">Looks Good!</span>
      </template>
      <template v-if="isSubmitForm6 && $v6.form6.firstName.$error">
        <span class="text-white bg-danger py-1 px-2 rounded">Please fill the first Name</span>
      </template>
    </div>
    <div :class="{ 'has-error': $v6.form6.lastName.$error, 'has-success': isSubmitForm6 && !$v6.form6.lastName.$error }">
      <label for="tlpLname">Last name</label>
      <input id="tlpLname" type="text" placeholder="Enter Last Name" class="form-input mb-2" v-model="form6.lastName" />
      <template v-if="isSubmitForm6 && !$v6.form6.lastName.$error">
        <span class="text-white bg-[#1abc9c] py-1 px-2 rounded">Looks Good!</span>
      </template>
      <template v-if="isSubmitForm6 && $v6.form6.lastName.$error">
        <span class="text-white bg-danger py-1 px-2 rounded">Please fill the last Name</span>
      </template>
    </div>
    <div :class="{ 'has-error': $v6.form6.userName.$error, 'has-success': isSubmitForm6 && !$v6.form6.userName.$error }">
      <label for="tlpEmail">Username</label>
      <div class="flex">
        <div
          class="
            bg-[#eee]
            flex
            justify-center
            items-center
            ltr:rounded-l-md
            rtl:rounded-r-md
            px-3
            font-semibold
            border
            ltr:border-r-0
            rtl:border-l-0
            border-[#e0e6ed]
            dark:border-[#17263c] dark:bg-[#1b2e4b]
          "
        >
          @
        </div>
        <input id="tlpEmail" type="text" placeholder="Enter Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none" v-model="form6.userName" />
      </div>
      <div class="mt-2">
        <template v-if="isSubmitForm6 && !$v6.form6.userName.$error">
          <span class="text-white bg-[#1abc9c] py-1 px-2 rounded">Looks Good!</span>
        </template>
        <template v-if="isSubmitForm6 && $v6.form6.userName.$error">
          <span class="text-white bg-danger py-1 px-2 rounded">Please choose a userName.</span>
        </template>
      </div>
    </div>
  </div>
  <div class="grid grid-cols-1 md:grid-cols-4 gap-5">
    <div class="md:col-span-2" :class="{ 'has-error': $v6.form6.city.$error, 'has-success': isSubmitForm6 && !$v6.form6.city.$error }">
      <label for="tlpCity">City</label>
      <input id="tlpCity" type="text" placeholder="Enter City" class="form-input mb-2" v-model="form6.city" />
      <template v-if="isSubmitForm6 && !$v6.form6.city.$error">
        <span class="text-white bg-[#1abc9c] py-1 px-2 rounded">Looks Good!</span>
      </template>
      <template v-if="isSubmitForm6 && $v6.form6.city.$error">
        <span class="text-white bg-danger py-1 px-2 rounded">Please provide a valid city.</span>
      </template>
    </div>
    <div :class="{ 'has-error': $v6.form6.state.$error, 'has-success': isSubmitForm6 && !$v6.form6.state.$error }">
      <label for="tlpState">State</label>
      <input id="tlpState" type="text" placeholder="Enter State" class="form-input mb-2" v-model="form6.state" />
      <template v-if="isSubmitForm6 && !$v6.form6.state.$error">
        <span class="text-white bg-[#1abc9c] py-1 px-2 rounded">Looks Good!</span>
      </template>
      <template v-if="isSubmitForm6 && $v6.form6.state.$error">
        <span class="text-white bg-danger py-1 px-2 rounded">Please provide a valid state.</span>
      </template>
    </div>
    <div :class="{ 'has-error': $v6.form6.zip.$error, 'has-success': isSubmitForm6 && !$v6.form6.zip.$error }">
      <label for="tlpZip">Zip</label>
      <input id="tlpZip" type="text" placeholder="Enter Zip" class="form-input mb-2" v-model="form6.zip" />
      <template v-if="isSubmitForm6 && !$v6.form6.zip.$error">
        <span class="text-white bg-[#1abc9c] py-1 px-2 rounded">Looks Good!</span>
      </template>
      <template v-if="isSubmitForm6 && $v6.form6.zip.$error">
        <span class="text-white bg-danger py-1 px-2 rounded">Please provide a valid Zip.</span>
      </template>
    </div>
  </div>
  <div :class="{ 'has-error': $v6.form6.isTerms.$error, 'has-success': isSubmitForm6 && !$v6.form6.isTerms.$error }">
    <label class="flex items-center cursor-pointer">
      <input type="checkbox" class="form-checkbox" v-model="form6.isTerms" />
      <span class="text-white-dark">Agree to terms and conditions</span>
    </label>
    <template v-if="isSubmitForm6 && $v6.form6.isTerms.$error">
      <div class="mt-2">
        <span class="text-white bg-danger py-1 px-2 rounded">You must agree before submitting.</span>
      </div>
    </template>
  </div>
  <button type="submit" class="btn btn-primary !mt-6">Submit Form</button>
</form>

<!-- script -->
<script lang="ts" setup>
  import { ref } from 'vue';
  import { useVuelidate } from '@vuelidate/core';
  import { required, email, sameAs } from '@vuelidate/validators';
  const form6 = ref({
    firstName: 'Shaun',
    lastName: 'Park',
    userName: '',
    city: '',
    state: '',
    zip: '',
    isTerms: false,
  });
  const isSubmitForm6 = ref(false);
  const rules6 = {
    form6: {
      firstName: { required },
      lastName: { required },
      userName: { required },
      city: { required },
      state: { required },
      zip: { required },
      isTerms: {
        sameAsRawValue: sameAs(true),
      },
    },
  };
  const $v6 = useVuelidate(rules6, { form6 });
  const submitForm6 = () => {
    isSubmitForm6.value = true;
    $v6.value.form6.$touch();
    if ($v6.value.form6.$invalid) {
      return false;
    }
    //form validated success
    showMessage('Form submitted successfully.');
  };
<\/script>
`,-1),Cs=ze({__name:"validation",setup(r){je({title:"Form Validation"});const{codeArr:o,toggleCode:a}=Oe(),s=V({name:""}),m=V(!1),N=re({form1:{name:{required:q}}},{form1:s}),p=()=>{if(m.value=!0,N.value.form1.$touch(),N.value.form1.$invalid)return!1;U("Form submitted successfully.")},h=V({email:""}),u=V(!1),v=re({form2:{email:{required:q,email:et}}},{form2:h}),E=()=>{if(u.value=!0,v.value.form2.$touch(),v.value.form2.$invalid)return!1;U("Form submitted successfully.")},x=V({select:""}),l=V(!1),d=re({form3:{select:{required:q}}},{form3:x}),C=()=>{if(l.value=!0,d.value.form3.$touch(),d.value.form3.$invalid)return!1;U("Form submitted successfully.")},z=V({firstName:"Shaun",lastName:"Park",userName:"",city:"",state:"",zip:"",isTerms:!1}),k=V(!1),A={form4:{firstName:{required:q},lastName:{required:q},userName:{required:q},city:{required:q},state:{required:q},zip:{required:q},isTerms:{sameAsRawValue:xe(!0)}}},_=re(A,{form4:z}),K=()=>{if(k.value=!0,_.value.form4.$touch(),_.value.form4.$invalid)return!1;U("Form submitted successfully.")},O=V({firstName:"Shaun",lastName:"Park",userName:"",city:"",state:"",zip:"",isTerms:!1}),Q=()=>{U("Form submitted successfully.")},j=V({firstName:"Shaun",lastName:"Park",userName:"",city:"",state:"",zip:"",isTerms:!1}),L=V(!1),ee={form6:{firstName:{required:q},lastName:{required:q},userName:{required:q},city:{required:q},state:{required:q},zip:{required:q},isTerms:{sameAsRawValue:xe(!0)}}},y=re(ee,{form6:j}),le=()=>{if(L.value=!0,y.value.form6.$touch(),y.value.form6.$invalid)return!1;U("Form submitted successfully.")},U=(te="",i="success")=>{qe.mixin({toast:!0,position:"top",showConfirmButton:!1,timer:3e3,customClass:{container:"toast"}}).fire({icon:i,title:te,padding:"10px 20px"})};return(te,i)=>(f(),g("div",null,[at,e("div",ot,[e("div",lt,[e("div",it,[M(Ae)]),nt,mt]),e("div",ut,[e("div",dt,[e("div",ct,[pt,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:i[0]||(i[0]=n=>t(a)("code1"))},[e("span",ft,[M(J,{class:"me-2"}),B(" Code ")])])]),e("div",vt,[e("form",{class:"space-y-5",onSubmit:i[2]||(i[2]=Y(n=>p(),["prevent"]))},[e("div",{class:T({"has-error":t(N).form1.name.$error,"has-success":m.value&&!t(N).form1.name.$error})},[bt,w(e("input",{id:"fullName",type:"text",placeholder:"Enter Full Name",class:"form-input","onUpdate:modelValue":i[1]||(i[1]=n=>s.value.name=n)},null,512),[[R,s.value.name]]),m.value&&!t(N).form1.name.$error?(f(),g("p",$t,"Looks Good!")):$("",!0),m.value&&t(N).form1.name.$error?(f(),g("p",ht,"Please fill the Name")):$("",!0)],2),yt],32)]),t(o).includes("code1")?(f(),H(X,{key:0},{default:W(()=>[gt]),_:1})):$("",!0)]),e("div",xt,[e("div",_t,[Nt,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:i[3]||(i[3]=n=>t(a)("code2"))},[e("span",Ft,[M(J,{class:"me-2"}),B(" Code ")])])]),e("div",kt,[e("form",{class:"space-y-5",onSubmit:i[5]||(i[5]=Y(n=>E(),["prevent"]))},[e("div",{class:T({"has-error":t(v).form2.email.$error,"has-success":u.value&&!t(v).form2.email.$error})},[wt,w(e("input",{id:"Email",type:"text",placeholder:"Enter Email",class:"form-input","onUpdate:modelValue":i[4]||(i[4]=n=>h.value.email=n)},null,512),[[R,h.value.email]]),u.value&&!t(v).form2.email.$error?(f(),g("p",St,"Looks Good!")):$("",!0),u.value&&t(v).form2.email.$error?(f(),g("p",Et,"Please fill the Email")):$("",!0)],2),Ct],32)]),t(o).includes("code2")?(f(),H(X,{key:0},{default:W(()=>[Lt]),_:1})):$("",!0)]),e("div",Vt,[e("div",Pt,[Rt,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:i[6]||(i[6]=n=>t(a)("code3"))},[e("span",zt,[M(J,{class:"me-2"}),B(" Code ")])])]),e("div",jt,[e("form",{class:"space-y-5",onSubmit:i[8]||(i[8]=Y(n=>C(),["prevent"]))},[e("div",{class:T({"has-error":t(d).form3.select.$error,"has-success":l.value&&!t(d).form3.select.$error})},[w(e("select",{class:"form-select text-white-dark","onUpdate:modelValue":i[7]||(i[7]=n=>x.value.select=n)},Ut,512),[[Te,x.value.select]]),l.value&&!t(d).form3.select.$error?(f(),g("p",Gt,"Example valid custom select feedback")):$("",!0),l.value&&t(d).form3.select.$error?(f(),g("p",Zt,"Please Select the field")):$("",!0)],2),It],32)]),t(o).includes("code3")?(f(),H(X,{key:0},{default:W(()=>[Mt]),_:1})):$("",!0)]),e("div",Dt,[e("div",Bt,[Yt,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:i[9]||(i[9]=n=>t(a)("code4"))},[e("span",Ht,[M(J,{class:"me-2"}),B(" Code ")])])]),e("div",Wt,[e("form",{class:"space-y-5",onSubmit:i[17]||(i[17]=Y(n=>K(),["prevent"]))},[e("div",Xt,[e("div",{class:T({"has-error":t(_).form4.firstName.$error,"has-success":k.value&&!t(_).form4.firstName.$error})},[Jt,w(e("input",{id:"customFname",type:"text",placeholder:"Enter First Name",class:"form-input","onUpdate:modelValue":i[10]||(i[10]=n=>z.value.firstName=n)},null,512),[[R,z.value.firstName]]),k.value&&!t(_).form4.firstName.$error?(f(),g("p",Kt,"Looks Good!")):$("",!0),k.value&&t(_).form4.firstName.$error?(f(),g("p",Qt,"Please fill the first name")):$("",!0)],2),e("div",{class:T({"has-error":t(_).form4.lastName.$error,"has-success":k.value&&!t(_).form4.lastName.$error})},[er,w(e("input",{id:"customLname",type:"text",placeholder:"Enter Last Name",class:"form-input","onUpdate:modelValue":i[11]||(i[11]=n=>z.value.lastName=n)},null,512),[[R,z.value.lastName]]),k.value&&!t(_).form4.lastName.$error?(f(),g("p",tr,"Looks Good!")):$("",!0),k.value&&t(_).form4.lastName.$error?(f(),g("p",rr,"Please fill the last name")):$("",!0)],2),e("div",{class:T({"has-error":t(_).form4.userName.$error,"has-success":k.value&&!t(_).form4.userName.$error})},[sr,e("div",ar,[or,w(e("input",{id:"customeEmail",type:"text",placeholder:"Enter Username",class:"form-input ltr:rounded-l-none rtl:rounded-r-none","onUpdate:modelValue":i[12]||(i[12]=n=>z.value.userName=n)},null,512),[[R,z.value.userName]])]),k.value&&!t(_).form4.userName.$error?(f(),g("p",lr,"Looks Good!")):$("",!0),k.value&&t(_).form4.userName.$error?(f(),g("p",ir,"Please choose a userName")):$("",!0)],2)]),e("div",nr,[e("div",{class:T(["md:col-span-2",{"has-error":t(_).form4.city.$error,"has-success":k.value&&!t(_).form4.city.$error}])},[mr,w(e("input",{id:"customeCity",type:"text",placeholder:"Enter City",class:"form-input","onUpdate:modelValue":i[13]||(i[13]=n=>z.value.city=n)},null,512),[[R,z.value.city]]),k.value&&!t(_).form4.city.$error?(f(),g("p",ur,"Looks Good!")):$("",!0),k.value&&t(_).form4.city.$error?(f(),g("p",dr,"Please provide a valid city")):$("",!0)],2),e("div",{class:T({"has-error":t(_).form4.state.$error,"has-success":k.value&&!t(_).form4.state.$error})},[cr,w(e("input",{id:"customeState",type:"text",placeholder:"Enter State",class:"form-input","onUpdate:modelValue":i[14]||(i[14]=n=>z.value.state=n)},null,512),[[R,z.value.state]]),k.value&&!t(_).form4.state.$error?(f(),g("p",pr,"Looks Good!")):$("",!0),k.value&&t(_).form4.state.$error?(f(),g("p",fr,"Please provide a valid state")):$("",!0)],2),e("div",{class:T({"has-error":t(_).form4.zip.$error,"has-success":k.value&&!t(_).form4.zip.$error})},[vr,w(e("input",{id:"customeZip",type:"text",placeholder:"Enter Zip",class:"form-input","onUpdate:modelValue":i[15]||(i[15]=n=>z.value.zip=n)},null,512),[[R,z.value.zip]]),k.value&&!t(_).form4.zip.$error?(f(),g("p",br,"Looks Good!")):$("",!0),k.value&&t(_).form4.zip.$error?(f(),g("p",$r,"Please provide a valid zip")):$("",!0)],2)]),e("div",{class:T({"has-error":t(_).form4.isTerms.$error,"has-success":k.value&&!t(_).form4.isTerms.$error})},[e("label",hr,[w(e("input",{type:"checkbox",class:"form-checkbox","onUpdate:modelValue":i[16]||(i[16]=n=>z.value.isTerms=n)},null,512),[[ie,z.value.isTerms]]),yr]),k.value&&t(_).form4.isTerms.$error?(f(),g("p",gr,"You must agree before submitting.")):$("",!0)],2),xr],32)]),t(o).includes("code4")?(f(),H(X,{key:0},{default:W(()=>[_r]),_:1})):$("",!0)]),e("div",Nr,[e("div",Fr,[kr,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:i[18]||(i[18]=n=>t(a)("code5"))},[e("span",wr,[M(J,{class:"me-2"}),B(" Code ")])])]),e("div",Sr,[e("form",{class:"space-y-5",onSubmit:i[26]||(i[26]=Y(n=>Q(),["prevent"]))},[e("div",Er,[e("div",null,[Cr,w(e("input",{id:"browserFname",type:"text",placeholder:"Enter First Name","onUpdate:modelValue":i[19]||(i[19]=n=>O.value.firstName=n),class:"form-input",required:""},null,512),[[R,O.value.firstName]])]),e("div",null,[Lr,w(e("input",{id:"browserLname",type:"text",placeholder:"Enter Last name","onUpdate:modelValue":i[20]||(i[20]=n=>O.value.lastName=n),class:"form-input",required:""},null,512),[[R,O.value.lastName]])]),e("div",null,[Vr,e("div",Pr,[Rr,w(e("input",{id:"browserEmail",type:"text",placeholder:"Enter Username","onUpdate:modelValue":i[21]||(i[21]=n=>O.value.userName=n),class:"form-input ltr:rounded-l-none rtl:rounded-r-none",required:""},null,512),[[R,O.value.userName]])])])]),e("div",zr,[e("div",jr,[Tr,w(e("input",{id:"browserCity",type:"text",placeholder:"Enter City","onUpdate:modelValue":i[22]||(i[22]=n=>O.value.city=n),class:"form-input",required:""},null,512),[[R,O.value.city]])]),e("div",null,[Or,w(e("input",{id:"browserState",type:"text",placeholder:"Enter State","onUpdate:modelValue":i[23]||(i[23]=n=>O.value.state=n),class:"form-input",required:""},null,512),[[R,O.value.state]])]),e("div",null,[qr,w(e("input",{id:"browserZip",type:"text",placeholder:"Enter Zip","onUpdate:modelValue":i[24]||(i[24]=n=>O.value.zip=n),class:"form-input",required:""},null,512),[[R,O.value.zip]])])]),e("div",null,[e("label",Ar,[w(e("input",{type:"checkbox",class:"form-checkbox","onUpdate:modelValue":i[25]||(i[25]=n=>O.value.isTerms=n),required:""},null,512),[[ie,O.value.isTerms]]),Ur])]),Gr],32)]),t(o).includes("code5")?(f(),H(X,{key:0},{default:W(()=>[Zr]),_:1})):$("",!0)]),e("div",Ir,[e("div",Mr,[Dr,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:i[27]||(i[27]=n=>t(a)("code6"))},[e("span",Br,[M(J,{class:"me-2"}),B(" Code ")])])]),e("div",Yr,[e("form",{class:"space-y-5",onSubmit:i[35]||(i[35]=Y(n=>le(),["prevent"]))},[e("div",Hr,[e("div",{class:T({"has-error":t(y).form6.firstName.$error,"has-success":L.value&&!t(y).form6.firstName.$error})},[Wr,w(e("input",{id:"tlpFname",type:"text",placeholder:"Enter First Name",class:"form-input mb-2","onUpdate:modelValue":i[28]||(i[28]=n=>j.value.firstName=n)},null,512),[[R,j.value.firstName]]),L.value&&!t(y).form6.firstName.$error?(f(),g("span",Xr,"Looks Good!")):$("",!0),L.value&&t(y).form6.firstName.$error?(f(),g("span",Jr,"Please fill the first Name")):$("",!0)],2),e("div",{class:T({"has-error":t(y).form6.lastName.$error,"has-success":L.value&&!t(y).form6.lastName.$error})},[Kr,w(e("input",{id:"tlpLname",type:"text",placeholder:"Enter Last Name",class:"form-input mb-2","onUpdate:modelValue":i[29]||(i[29]=n=>j.value.lastName=n)},null,512),[[R,j.value.lastName]]),L.value&&!t(y).form6.lastName.$error?(f(),g("span",Qr,"Looks Good!")):$("",!0),L.value&&t(y).form6.lastName.$error?(f(),g("span",es,"Please fill the last Name")):$("",!0)],2),e("div",{class:T({"has-error":t(y).form6.userName.$error,"has-success":L.value&&!t(y).form6.userName.$error})},[ts,e("div",rs,[ss,w(e("input",{id:"tlpEmail",type:"text",placeholder:"Enter Username",class:"form-input ltr:rounded-l-none rtl:rounded-r-none","onUpdate:modelValue":i[30]||(i[30]=n=>j.value.userName=n)},null,512),[[R,j.value.userName]])]),e("div",as,[L.value&&!t(y).form6.userName.$error?(f(),g("span",os,"Looks Good!")):$("",!0),L.value&&t(y).form6.userName.$error?(f(),g("span",ls,"Please choose a userName.")):$("",!0)])],2)]),e("div",is,[e("div",{class:T(["md:col-span-2",{"has-error":t(y).form6.city.$error,"has-success":L.value&&!t(y).form6.city.$error}])},[ns,w(e("input",{id:"tlpCity",type:"text",placeholder:"Enter City",class:"form-input mb-2","onUpdate:modelValue":i[31]||(i[31]=n=>j.value.city=n)},null,512),[[R,j.value.city]]),L.value&&!t(y).form6.city.$error?(f(),g("span",ms,"Looks Good!")):$("",!0),L.value&&t(y).form6.city.$error?(f(),g("span",us,"Please provide a valid city.")):$("",!0)],2),e("div",{class:T({"has-error":t(y).form6.state.$error,"has-success":L.value&&!t(y).form6.state.$error})},[ds,w(e("input",{id:"tlpState",type:"text",placeholder:"Enter State",class:"form-input mb-2","onUpdate:modelValue":i[32]||(i[32]=n=>j.value.state=n)},null,512),[[R,j.value.state]]),L.value&&!t(y).form6.state.$error?(f(),g("span",cs,"Looks Good!")):$("",!0),L.value&&t(y).form6.state.$error?(f(),g("span",ps,"Please provide a valid state.")):$("",!0)],2),e("div",{class:T({"has-error":t(y).form6.zip.$error,"has-success":L.value&&!t(y).form6.zip.$error})},[fs,w(e("input",{id:"tlpZip",type:"text",placeholder:"Enter Zip",class:"form-input mb-2","onUpdate:modelValue":i[33]||(i[33]=n=>j.value.zip=n)},null,512),[[R,j.value.zip]]),L.value&&!t(y).form6.zip.$error?(f(),g("span",vs,"Looks Good!")):$("",!0),L.value&&t(y).form6.zip.$error?(f(),g("span",bs,"Please provide a valid Zip.")):$("",!0)],2)]),e("div",{class:T({"has-error":t(y).form6.isTerms.$error,"has-success":L.value&&!t(y).form6.isTerms.$error})},[e("label",$s,[w(e("input",{type:"checkbox",class:"form-checkbox","onUpdate:modelValue":i[34]||(i[34]=n=>j.value.isTerms=n)},null,512),[[ie,j.value.isTerms]]),hs]),L.value&&t(y).form6.isTerms.$error?(f(),g("div",ys,xs)):$("",!0)],2),_s],32)]),t(o).includes("code6")?(f(),H(X,{key:0},{default:W(()=>[Ns]),_:1})):$("",!0)])])])]))}});export{Cs as default};
