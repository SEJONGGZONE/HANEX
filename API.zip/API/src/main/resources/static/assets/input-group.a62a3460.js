import{c as y,_ as a}from"./codePreview.3a0651de.js";import{d as w,u as j,a as C,o as n,b as L,e,g as r,f as t,j as c,Y as b,w as o,D as u,ao as x,k as p,p as R,N as g,E as _}from"./index.2327c8d6.js";import{I as f}from"./icon-code.45f37684.js";import{I as k}from"./icon-loader.d708af81.js";const S=e("ul",{class:"flex space-x-2 rtl:space-x-reverse"},[e("li",null,[e("a",{href:"javascript:;",class:"text-primary hover:underline"},"Forms")]),e("li",{class:"before:content-['/'] ltr:before:mr-2 rtl:before:ml-2"},[e("span",null,"Input Group")])],-1),A={class:"pt-5 space-y-4"},B={class:"grid grid-cols-1 xl:grid-cols-2 gap-4"},$={class:"panel lg:row-span-2"},D={class:"flex items-center justify-between mb-5"},P=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Default",-1),N={class:"flex items-center"},I=p('<div class="mb-5"><form><div class="mb-5"><div class="flex"><div class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"> @ </div><input type="text" placeholder="Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none"></div></div><div class="mb-5"><div class="flex"><input type="text" placeholder="Recipient&#39;s username" class="form-input ltr:rounded-r-none rtl:rounded-l-none"><div class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"> @example.com </div></div></div><div class="mb-5"><label for="url">Your vanity URL</label><div class="flex"><div class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"> https:// </div><input id="url" type="text" placeholder="example.com/users/" class="form-input ltr:rounded-l-none rtl:rounded-r-none"></div></div><div class="mb-5"><div class="flex"><div class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"> $ </div><input type="text" placeholder="" class="form-input rounded-none"><div class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"> .00 </div></div></div><div><div class="flex"><div class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b] whitespace-nowrap"> With textarea </div><textarea rows="4" class="form-textarea ltr:rounded-l-none rtl:rounded-r-none"></textarea></div></div></form></div>',1),U=e("pre",null,`<!-- basic -->
<form>
  <div class="mb-5">
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        @
      </div>
      <input type="text" placeholder="Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
    </div>
  </div>
  <div class="mb-5">
    <div class="flex">
      <input type="text" placeholder="Recipient's username" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        @example.com
      </div>
    </div>
  </div>
  <div class="mb-5">
    <label for="url">Your vanity URL</label>
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        https://
      </div>
      <input id="url" type="text" placeholder="example.com/users/" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
    </div>
  </div>
  <div class="mb-5">
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        $
      </div>
      <input type="text" placeholder="" class="form-input rounded-none" />
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        .00
      </div>
    </div>
  </div>
  <div>
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b] whitespace-nowrap"
      >
        With textarea
      </div>
      <textarea rows="4" class="form-textarea ltr:rounded-l-none rtl:rounded-r-none"></textarea>
    </div>
  </div>
</form>
`,-1),z={class:"panel"},F={class:"flex items-center justify-between mb-5"},M=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Simple Icon",-1),V={class:"flex items-center"},Y={class:"mb-5"},E={class:"mb-5"},G=e("label",{for:"iconLeft"},"Left",-1),W={class:"flex"},T={class:"bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"},q=e("input",{id:"iconLeft",type:"text",placeholder:"Notification",class:"form-input ltr:rounded-l-none rtl:rounded-r-none"},null,-1),H=e("label",{for:"iconRight"},"Right",-1),J={class:"flex"},K=e("input",{id:"iconRight",type:"text",placeholder:"Notification",class:"form-input ltr:rounded-r-none rtl:rounded-l-none"},null,-1),O={class:"bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"},Q=e("pre",null,`<!-- left -->
<div class="flex">
  <div
    class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
  >
    <svg>...</svg>
  </div>
  <input id="iconLeft" type="text" placeholder="Notification" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
</div>

<!-- right -->
<div class="flex">
  <input id="iconRight" type="text" placeholder="Notification" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
  <div
    class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
  >
    <svg>... </svg>
  </div>
</div>
`,-1),X={class:"panel"},Z={class:"flex items-center justify-between mb-5"},ee=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Spinning Icon",-1),re={class:"flex items-center"},te={class:"mb-5"},de={class:"mb-5"},oe=e("label",{for:"spiLeft"},"Left",-1),le={class:"flex"},ne={class:"bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"},se=e("input",{id:"spiLeft",type:"text",placeholder:"Spinners",class:"form-input ltr:rounded-l-none rtl:rounded-r-none"},null,-1),ie=e("label",{for:"spiRight"},"Right",-1),ae={class:"flex"},ce=e("input",{id:"spiRight",type:"text",placeholder:"Spinners",class:"form-input ltr:rounded-r-none rtl:rounded-l-none"},null,-1),be={class:"bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"},ue=e("pre",null,`<!-- left -->
<div class="flex">
  <div
    class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
  >
    <svg> ... </svg>
  </div>
  <input id="spiLeft" type="text" placeholder="Spinners" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
</div>

<!-- right -->
<div class="flex">
  <input id="spiRight" type="text" placeholder="Spinners" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
  <div
    class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
  >
    <svg> ...  </svg>
  </div>
</div>
`,-1),fe={class:"panel"},pe={class:"flex items-center justify-between mb-5"},me=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Dropdown Icon",-1),he={class:"flex items-center"},ve={class:"mb-5"},xe={class:"dropdown mb-5"},ge=e("label",{for:"dropdownLeft"},"Left",-1),_e={class:"flex"},ke={class:"bg-primary flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] cursor-pointer h-full"},ye=["onClick"],we=e("li",null,[e("a",{href:"javascript:;"},"Action")],-1),je=e("li",null,[e("a",{href:"javascript:;"},"Another action")],-1),Ce=e("li",null,[e("a",{href:"javascript:;"},"Something else here")],-1),Le=e("li",null,[e("a",{href:"javascript:;"},"Separated link")],-1),Re=[we,je,Ce,Le],Se=e("input",{id:"dropdownLeft",type:"text",placeholder:"Dropdown",class:"form-input ltr:rounded-l-none rtl:rounded-r-none"},null,-1),Ae={class:"dropdown"},Be=e("label",{for:"dropdownRight"},"Right",-1),$e={class:"flex"},De=e("input",{id:"dropdownRight",type:"text",placeholder:"Dropdown",class:"form-input ltr:rounded-r-none rtl:rounded-l-none"},null,-1),Pe={class:"bg-success flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] cursor-pointer h-full"},Ne=["onClick"],Ie=e("li",null,[e("a",{href:"javascript:;"},"Action")],-1),Ue=e("li",null,[e("a",{href:"javascript:;"},"Another action")],-1),ze=e("li",null,[e("a",{href:"javascript:;"},"Something else here")],-1),Fe=e("li",null,[e("a",{href:"javascript:;"},"Separated link")],-1),Me=[Ie,Ue,ze,Fe],Ve=e("pre",null,`<!-- left -->
<div class="flex">
  <Popper :placement="store.rtlClass === 'rtl' ? 'bottom-end' : 'bottom-start'" offsetDistance="0" class="align-middle input-group-dropodwn">
    <div
      class="bg-primary flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] cursor-pointer h-full"
    >
      <svg> ... </svg>
    </div>
    <template #content="{ close }">
      <ul @click="close()">
        <li><a href="javascript:;">Action</a></li>
        <li><a href="javascript:;">Another action</a></li>
        <li><a href="javascript:;">Something else here</a></li>
        <li><a href="javascript:;">Separated link</a></li>
      </ul>
    </template>
  </Popper>
  <input id="dropdownLeft" type="text" placeholder="Dropdown" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
</div>

<!-- right -->
<div class="flex">
  <input id="dropdownRight" type="text" placeholder="Dropdown" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
  <Popper :placement="store.rtlClass === 'rtl' ? 'bottom-start' : 'bottom-end'" offsetDistance="0" class="align-middle input-group-dropodwn">
    <div
      class="bg-success flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] cursor-pointer h-full"
    >
      <svg> ... </svg>
    </div>
    <template #content="{ close }">
      <ul @click="close()">
        <li><a href="javascript:;">Action</a></li>
        <li><a href="javascript:;">Another action</a></li>
        <li><a href="javascript:;">Something else here</a></li>
        <li><a href="javascript:;">Separated link</a></li>
      </ul>
    </template>
  </Popper>
</div>
`,-1),Ye={class:"panel"},Ee={class:"flex items-center justify-between mb-5"},Ge=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Checkboxes",-1),We={class:"flex items-center"},Te=p('<div class="mb-5"><div class="mb-5"><label for="checkLeft">Left</label><div class="flex"><div class="bg-[#f1f2f3] dark:bg-[#1b2e4b] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c]"><input type="checkbox" class="form-checkbox border-[#e0e6ed] dark:border-white-dark ltr:mr-0 rtl:ml-0" checked></div><input id="checkLeft" type="text" placeholder="Checkbox" class="form-input ltr:rounded-l-none rtl:rounded-r-none"></div></div><div><label for="checkRight">Right</label><div class="flex"><input id="checkRight" type="text" placeholder="Checkbox" class="form-input ltr:rounded-r-none rtl:rounded-l-none"><div class="bg-[#f1f2f3] dark:bg-[#1b2e4b] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c]"><input type="checkbox" class="form-checkbox text-warning border-[#e0e6ed] dark:border-white-dark ltr:mr-0 rtl:ml-0" checked></div></div></div></div>',1),qe=e("pre",null,`<!-- left -->
<div class="flex">
  <div
    class="bg-[#f1f2f3] dark:bg-[#1b2e4b] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c]"
  >
    <input type="checkbox" class="form-checkbox border-[#e0e6ed] dark:border-white-dark ltr:mr-0 rtl:ml-0" checked />
  </div>
  <input id="checkLeft" type="text" placeholder="Checkbox" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
</div>

<!-- right -->
<div class="flex">
  <input id="checkRight" type="text" placeholder="Checkbox" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
  <div
    class="bg-[#f1f2f3] dark:bg-[#1b2e4b] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c]"
  >
    <input type="checkbox" class="form-checkbox text-warning border-[#e0e6ed] dark:border-white-dark ltr:mr-0 rtl:ml-0" checked />
  </div>
</div>
`,-1),He={class:"panel"},Je={class:"flex items-center justify-between mb-5"},Ke=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Radios",-1),Oe={class:"flex items-center"},Qe=p('<div class="mb-5"><div class="mb-5"><label for="radioLeft">Left</label><div class="flex"><div class="bg-[#f1f2f3] dark:bg-[#1b2e4b] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c]"><input type="radio" class="form-radio text-info border-[#e0e6ed] dark:border-white-dark ltr:mr-0 rtl:ml-0" checked></div><input id="radioLeft" type="text" placeholder="Radio" class="form-input ltr:rounded-l-none rtl:rounded-r-none"></div></div><div><label for="radioRight">Right</label><div class="flex"><input id="radioRight" type="text" placeholder="Radio" class="form-input ltr:rounded-r-none rtl:rounded-l-none"><div class="bg-[#f1f2f3] dark:bg-[#1b2e4b] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c]"><input type="radio" class="form-radio text-danger border-[#e0e6ed] dark:border-white-dark ltr:mr-0 rtl:ml-0" checked></div></div></div></div>',1),Xe=e("pre",null,`<!-- left -->
<div class="flex">
  <div
    class="bg-[#f1f2f3] dark:bg-[#1b2e4b] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c]"
  >
    <input type="radio" class="form-radio text-info border-[#e0e6ed] dark:border-white-dark ltr:mr-0 rtl:ml-0" checked />
  </div>
  <input id="radioLeft" type="text" placeholder="Radio" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
</div>

<!-- right -->
<div class="flex">
  <input id="radioRight" type="text" placeholder="Radio" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
  <div
    class="bg-[#f1f2f3] dark:bg-[#1b2e4b] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c]"
  >
    <input type="radio" class="form-radio text-danger border-[#e0e6ed] dark:border-white-dark ltr:mr-0 rtl:ml-0" checked />
  </div>
</div>
`,-1),Ze={class:"panel"},er={class:"flex items-center justify-between mb-5"},rr=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Switch",-1),tr={class:"flex items-center"},dr=p('<div class="mb-5"><div class="mb-5"><label for="switchLeft">Left</label><div class="flex"><div class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"><label class="w-7 h-4 relative cursor-pointer mb-0"><input type="checkbox" class="peer absolute w-full h-full opacity-0 z-10 focus:ring-0 focus:outline-none cursor-pointer" id="custom_switch_checkbox1"><span class="rounded-full border border-[#adb5bd] bg-white peer-checked:bg-primary peer-checked:border-primary dark:bg-dark block h-full before:absolute ltr:before:left-0.5 rtl:before:right-0.5 ltr:peer-checked:before:left-3.5 rtl:peer-checked:before:right-3.5 peer-checked:before:bg-white before:bg-[#adb5bd] dark:before:bg-white-dark before:bottom-[2px] before:w-3 before:h-3 before:rounded-full before:transition-all before:duration-300"></span></label></div><input id="switchLeft" type="text" placeholder="Switch" class="form-input ltr:rounded-l-none rtl:rounded-r-none"></div></div><div><label for="switchRight">Right</label><div class="flex"><input id="switchRight" type="text" placeholder="Switch" class="form-input ltr:rounded-r-none rtl:rounded-l-none"><div class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"><label class="w-7 h-4 relative cursor-pointer mb-0"><input type="checkbox" class="peer absolute w-full h-full opacity-0 z-10 focus:ring-0 focus:outline-none cursor-pointer" id="custom_switch_checkbox2"><span class="rounded-full border border-[#adb5bd] bg-white peer-checked:bg-primary peer-checked:border-primary dark:bg-dark block h-full before:absolute ltr:before:left-0.5 rtl:before:right-0.5 ltr:peer-checked:before:left-3.5 rtl:peer-checked:before:right-3.5 peer-checked:before:bg-white before:bg-[#adb5bd] dark:before:bg-white-dark before:bottom-[2px] before:w-3 before:h-3 before:rounded-full before:transition-all before:duration-300"></span></label></div></div></div></div>',1),or=e("pre",null,`<!-- left -->
<div class="flex">
  <div
    class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
  >
    <label class="w-7 h-4 relative cursor-pointer mb-0">
      <input type="checkbox" class="peer absolute w-full h-full opacity-0 z-10 focus:ring-0 focus:outline-none cursor-pointer" id="custom_switch_checkbox1" />
      <span
        class="rounded-full border border-[#adb5bd] bg-white peer-checked:bg-primary peer-checked:border-primary dark:bg-dark block h-full before:absolute ltr:before:left-0.5 rtl:before:right-0.5 ltr:peer-checked:before:left-3.5 rtl:peer-checked:before:right-3.5 peer-checked:before:bg-white before:bg-[#adb5bd] dark:before:bg-white-dark before:bottom-[2px] before:w-3 before:h-3 before:rounded-full before:transition-all before:duration-300"
      ></span>
    </label>
  </div>
  <input id="switchLeft" type="text" placeholder="Switch" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
</div>

<!-- right -->
<div class="flex">
  <input id="switchRight" type="text" placeholder="Switch" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
  <div
    class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
  >
    <label class="w-7 h-4 relative cursor-pointer mb-0">
      <input type="checkbox" class="peer absolute w-full h-full opacity-0 z-10 focus:ring-0 focus:outline-none cursor-pointer" id="custom_switch_checkbox2" />
      <span
        class="rounded-full border border-[#adb5bd] bg-white peer-checked:bg-primary peer-checked:border-primary dark:bg-dark block h-full before:absolute ltr:before:left-0.5 rtl:before:right-0.5 ltr:peer-checked:before:left-3.5 rtl:peer-checked:before:right-3.5 peer-checked:before:bg-white before:bg-[#adb5bd] dark:before:bg-white-dark before:bottom-[2px] before:w-3 before:h-3 before:rounded-full before:transition-all before:duration-300"
      ></span>
    </label>
  </div>
</div>
`,-1),lr={class:"panel"},nr={class:"flex items-center justify-between mb-5"},sr=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Sizes",-1),ir={class:"flex items-center"},ar=p('<div class="mb-5"><form><div class="mb-5"><div class="flex"><div class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"> Small </div><input type="text" placeholder="Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none py-2.5 text-base"></div></div><div class="mb-5"><div class="flex"><div class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"> Small </div><input type="text" placeholder="Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none"></div></div><div><div class="flex"><div class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"> Small </div><input type="text" placeholder="Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none py-1.5 text-xs"></div></div></form></div>',1),cr=e("pre",null,`<!-- sizes -->
<form>
  <div class="mb-5">
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        Small
      </div>
      <input type="text" placeholder="Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none py-2.5 text-base" />
    </div>
  </div>
  <div class="mb-5">
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        Small
      </div>
      <input type="text" placeholder="Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
    </div>
  </div>
  <div>
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        Small
      </div>
      <input type="text" placeholder="Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none py-1.5 text-xs" />
    </div>
  </div>
</form>
`,-1),br={class:"grid grid-cols-1 xl:grid-cols-2 gap-4"},ur={class:"panel"},fr={class:"flex items-center justify-between mb-5"},pr=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Multiple inputs",-1),mr={class:"flex items-center"},hr=p('<div class="mb-5"><form><div class="flex"><div class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"> First and last name </div><input type="text" placeholder="First Name" class="form-input ltr:border-r-0 rtl:border-l-0 focus:!border-r focus:!border-l rounded-none flex-1"><input type="text" placeholder="Last Name" class="form-input ltr:rounded-l-none rtl:rounded-r-none flex-1"></div></form></div>',1),vr=e("pre",null,`<!-- multiple inputs -->
<form>
  <div class="flex">
    <div
      class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
    >
      First and last name
    </div>
    <input type="text" placeholder="First Name" class="form-input ltr:border-r-0 rtl:border-l-0 focus:!border-r focus:!border-l rounded-none flex-1" />
    <input type="text" placeholder="Last Name" class="form-input ltr:rounded-l-none rtl:rounded-r-none flex-1" />
  </div>
</form>
`,-1),xr={class:"panel"},gr={class:"flex items-center justify-between mb-5"},_r=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Multiple addons",-1),kr={class:"flex items-center"},yr=p('<div class="mb-5"><form><div class="mb-5"><div class="flex"><div class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"> $ </div><div class="bg-[#eee] flex justify-center items-center rounded-none px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"> 0.00 </div><input type="text" placeholder="" class="form-input ltr:rounded-l-none rtl:rounded-r-none flex-1"></div></div><div><div class="flex"><input type="text" placeholder="" class="form-input ltr:rounded-r-none rtl:rounded-l-none flex-1 ltr:rounded-l-md rtl:rounded-r-md"><div class="bg-[#eee] flex justify-center items-center rounded-none px-3 font-semibold border border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"> 0.00 </div><div class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"> $ </div></div></div></form></div>',1),wr=e("pre",null,`<!-- basic -->
<form>
  <div class="mb-5">
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        $
      </div>
      <div class="bg-[#eee] flex justify-center items-center rounded-none px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]">
        0.00
      </div>
      <input type="text" placeholder="" class="form-input ltr:rounded-l-none rtl:rounded-r-none flex-1" />
    </div>
  </div>
  <div>
    <div class="flex">
      <input type="text" placeholder="" class="form-input ltr:rounded-r-none rtl:rounded-l-none flex-1 ltr:rounded-l-md rtl:rounded-r-md" />
      <div class="bg-[#eee] flex justify-center items-center rounded-none px-3 font-semibold border border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]">0.00</div>
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        $
      </div>
    </div>
  </div>
</form>
`,-1),jr={class:"grid grid-cols-1 xl:grid-cols-2 gap-4"},Cr={class:"panel"},Lr={class:"flex items-center justify-between mb-5"},Rr=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Buttons with dropdowns",-1),Sr={class:"flex items-center"},Ar={class:"mb-5"},Br={class:"mb-5 dropdown"},$r=e("label",{for:"dropdownLeftButton"},"Left",-1),Dr={class:"flex"},Pr=e("div",{class:"bg-primary text-white flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] cursor-pointer h-full"}," Dropdown ",-1),Nr=["onClick"],Ir=e("li",null,[e("a",{href:"javascript:;"},"Action")],-1),Ur=e("li",null,[e("a",{href:"javascript:;"},"Another action")],-1),zr=e("li",null,[e("a",{href:"javascript:;"},"Something else here")],-1),Fr=e("li",null,[e("a",{href:"javascript:;"},"Separated link")],-1),Mr=[Ir,Ur,zr,Fr],Vr=e("input",{id:"dropdownLeftButton",type:"text",placeholder:"",class:"form-input ltr:rounded-l-none rtl:rounded-r-none"},null,-1),Yr={class:"dropdown"},Er=e("label",{for:"dropdownRightButton"},"Right",-1),Gr={class:"flex"},Wr=e("input",{id:"dropdownRightButton",type:"text",placeholder:"",class:"form-input ltr:rounded-r-none rtl:rounded-l-none"},null,-1),Tr=e("div",{class:"bg-danger text-white flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] cursor-pointer h-full"}," Dropdown ",-1),qr=["onClick"],Hr=e("li",null,[e("a",{href:"javascript:;"},"Action")],-1),Jr=e("li",null,[e("a",{href:"javascript:;"},"Another action")],-1),Kr=e("li",null,[e("a",{href:"javascript:;"},"Something else here")],-1),Or=e("li",null,[e("a",{href:"javascript:;"},"Separated link")],-1),Qr=[Hr,Jr,Kr,Or],Xr=e("pre",null,`<!-- buttons with dropdowns -->
<form>
  <div class="mb-5 dropdown">
    <label for="dropdownLeftButton">Left</label>
    <div class="flex">
      <Popper :placement="store.rtlClass === 'rtl' ? 'bottom-end' : 'bottom-start'" offsetDistance="0" class="align-middle input-group-dropodwn">
        <div
          class="bg-primary text-white flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] cursor-pointer h-full"
        >
          Dropdown
        </div>
        <template #content="{ close }">
          <ul @click="close()">
            <li><a href="javascript:;">Action</a></li>
            <li><a href="javascript:;">Another action</a></li>
            <li><a href="javascript:;">Something else here</a></li>
            <li><a href="javascript:;">Separated link</a></li>
          </ul>
        </template>
      </Popper>
      <input id="dropdownLeftButton" type="text" placeholder="" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
    </div>
  </div>
  <div class="dropdown">
    <label for="dropdownRightButton">Right</label>
    <div class="flex">
      <input id="dropdownRightButton" type="text" placeholder="" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
      <Popper :placement="store.rtlClass === 'rtl' ? 'bottom-start' : 'bottom-end'" offsetDistance="0" class="align-middle input-group-dropodwn">
        <div
          class="bg-danger text-white flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] cursor-pointer h-full"
        >
          Dropdown
        </div>
        <template #content="{ close }">
          <ul @click="close()">
            <li><a href="javascript:;">Action</a></li>
            <li><a href="javascript:;">Another action</a></li>
            <li><a href="javascript:;">Something else here</a></li>
            <li><a href="javascript:;">Separated link</a></li>
          </ul>
        </template>
      </Popper>
    </div>
  </div>
</form>
`,-1),Zr={class:"panel"},et={class:"flex items-center justify-between mb-5"},rt=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Segmented buttons",-1),tt={class:"flex items-center"},dt={class:"mb-5"},ot={class:"mb-5 dropdown"},lt=e("label",{for:"btnLeft"},"Left",-1),nt={class:"flex"},st=e("div",{class:"bg-info text-white flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-info"}," Action ",-1),it={class:"bg-white dark:bg-[#1b2e4b] text-info flex justify-center items-center rounded-none px-3 font-semibold border border-info cursor-pointer h-full"},at=["onClick"],ct=e("li",null,[e("a",{href:"javascript:;"},"Action")],-1),bt=e("li",null,[e("a",{href:"javascript:;"},"Another action")],-1),ut=e("li",null,[e("a",{href:"javascript:;"},"Something else here")],-1),ft=e("li",null,[e("a",{href:"javascript:;"},"Separated link")],-1),pt=[ct,bt,ut,ft],mt=e("input",{id:"btnLeft",type:"text",placeholder:"",class:"form-input ltr:rounded-l-none rtl:rounded-r-none ltr:border-l-0 rtl:border-r-0"},null,-1),ht={class:"dropdown"},vt=e("label",{for:"btnRight"},"Right",-1),xt={class:"flex"},gt=e("input",{id:"btnRight",type:"text",placeholder:"",class:"form-input ltr:rounded-r-none rtl:rounded-l-none ltr:border-r-0 rtl:border-l-0"},null,-1),_t={class:"bg-white dark:bg-[#1b2e4b] text-secondary flex justify-center items-center rounded-none px-3 font-semibold border border-secondary cursor-pointer h-full"},kt=["onClick"],yt=e("li",null,[e("a",{href:"javascript:;"},"Action")],-1),wt=e("li",null,[e("a",{href:"javascript:;"},"Another action")],-1),jt=e("li",null,[e("a",{href:"javascript:;"},"Something else here")],-1),Ct=e("li",null,[e("a",{href:"javascript:;"},"Separated link")],-1),Lt=[yt,wt,jt,Ct],Rt=e("div",{class:"bg-secondary text-white flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-secondary cursor-pointer"}," Action ",-1),St=e("pre",null,`<!-- segmented buttons -->
<form>
  <div class="mb-5 dropdown">
    <label for="btnLeft">Left</label>
    <div class="flex">
      <div class="bg-info text-white flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-info">Action</div>
      <Popper :placement="store.rtlClass === 'rtl' ? 'bottom-end' : 'bottom-start'" offsetDistance="0" class="align-middle input-group-dropodwn">
        <div class="bg-white dark:bg-[#1b2e4b] text-info flex justify-center items-center rounded-none px-3 font-semibold border border-info cursor-pointer h-full">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5">
            <path d="M19 9L12 15L5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
          </svg>
        </div>
        <template #content="{ close }">
          <ul @click="close()">
            <li><a href="javascript:;">Action</a></li>
            <li><a href="javascript:;">Another action</a></li>
            <li><a href="javascript:;">Something else here</a></li>
            <li><a href="javascript:;">Separated link</a></li>
          </ul>
        </template>
      </Popper>
      <input id="btnLeft" type="text" placeholder="" class="form-input ltr:rounded-l-none rtl:rounded-r-none ltr:border-l-0 rtl:border-r-0" />
    </div>
  </div>
  <div class="dropdown">
    <label for="btnRight">Right</label>
    <div class="flex">
      <input id="btnRight" type="text" placeholder="" class="form-input ltr:rounded-r-none rtl:rounded-l-none ltr:border-r-0 rtl:border-l-0" />
      <Popper :placement="store.rtlClass === 'rtl' ? 'bottom-start' : 'bottom-end'" offsetDistance="0" class="align-middle input-group-dropodwn">
        <div class="bg-white dark:bg-[#1b2e4b] text-secondary flex justify-center items-center rounded-none px-3 font-semibold border border-secondary cursor-pointer h-full">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5">
            <path d="M19 9L12 15L5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
          </svg>
        </div>
        <template #content="{ close }">
          <ul @click="close()">
            <li><a href="javascript:;">Action</a></li>
            <li><a href="javascript:;">Another action</a></li>
            <li><a href="javascript:;">Something else here</a></li>
            <li><a href="javascript:;">Separated link</a></li>
          </ul>
        </template>
      </Popper>
      <div
        class="bg-secondary text-white flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-secondary cursor-pointer"
      >
        Action
      </div>
    </div>
  </div>
</form>
`,-1),At={class:"panel lg:col-span-2"},Bt={class:"flex items-center justify-between mb-5"},$t=e("h5",{class:"font-semibold text-lg dark:text-white-light"},"Button addons",-1),Dt={class:"flex items-center"},Pt=p('<div class="mb-5"><form><div class="mb-5"><label for="addonsLeft">Left</label><div class="flex"><button type="button" class="btn btn-info ltr:rounded-r-none rtl:rounded-l-none">Button</button><input id="addonsLeft" type="text" placeholder="" class="form-input ltr:rounded-l-none rtl:rounded-r-none"></div></div><div class="mb-5"><label for="addonsRight">Right</label><div class="flex"><input id="addonsRight" type="text" placeholder="" class="form-input ltr:rounded-r-none rtl:rounded-l-none"><button type="button" class="btn btn-secondary ltr:rounded-l-none rtl:rounded-r-none">Button</button></div></div><div class="mb-5"><label for="addonsLeftoutline">Left</label><div class="flex"><button type="button" class="btn btn-outline-info ltr:rounded-r-none rtl:rounded-l-none">Button</button><button type="button" class="btn btn-outline-info rounded-none ltr:border-l-0 rtl:border-r-0">Button</button><input id="addonsLeftoutline" type="text" placeholder="" class="form-input ltr:rounded-l-none rtl:rounded-r-none"></div></div><div><label for="addonsRightoutline">Right</label><div class="flex"><input id="addonsRightoutline" type="text" placeholder="" class="form-input ltr:rounded-r-none rtl:rounded-l-none"><button type="button" class="btn btn-outline-secondary rounded-none ltr:border-r-0 rtl:border-l-0">Button</button><button type="button" class="btn btn-outline-secondary ltr:rounded-l-none rtl:rounded-r-none">Button</button></div></div></form></div>',1),Nt=e("pre",null,`<!-- button addons -->
<form>
  <div class="mb-5">
    <label for="addonsLeft">Left</label>
    <div class="flex">
      <button type="button" class="btn btn-info ltr:rounded-r-none rtl:rounded-l-none">Button</button>
      <input id="addonsLeft" type="text" placeholder="" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
    </div>
  </div>
  <div class="mb-5">
    <label for="addonsRight">Right</label>
    <div class="flex">
      <input id="addonsRight" type="text" placeholder="" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
      <button type="button" class="btn btn-secondary ltr:rounded-l-none rtl:rounded-r-none">Button</button>
    </div>
  </div>
  <div class="mb-5">
    <label for="addonsLeftoutline">Left</label>
    <div class="flex">
      <button type="button" class="btn btn-outline-info ltr:rounded-r-none rtl:rounded-l-none">Button</button>
      <button type="button" class="btn btn-outline-info rounded-none ltr:border-l-0 rtl:border-r-0">Button</button>
      <input id="addonsLeftoutline" type="text" placeholder="" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
    </div>
  </div>
  <div>
    <label for="addonsRightoutline">Right</label>
    <div class="flex">
      <input id="addonsRightoutline" type="text" placeholder="" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
      <button type="button" class="btn btn-outline-secondary rounded-none ltr:border-r-0 rtl:border-l-0">Button</button>
      <button type="button" class="btn btn-outline-secondary ltr:rounded-l-none rtl:rounded-r-none">Button</button>
    </div>
  </div>
</form>
`,-1),Yt=w({__name:"input-group",setup(It){j({title:"Input Group"});const m=C(),{codeArr:s,toggleCode:i}=y();return(Ut,d)=>{const h=R("Popper");return n(),L("div",null,[S,e("div",A,[e("div",B,[e("div",$,[e("div",D,[P,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:d[0]||(d[0]=l=>r(i)("code1"))},[e("span",N,[t(f,{class:"me-2"}),c(" Code ")])])]),I,r(s).includes("code1")?(n(),b(a,{key:0},{default:o(()=>[U]),_:1})):u("",!0)]),e("div",z,[e("div",F,[M,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:d[1]||(d[1]=l=>r(i)("code2"))},[e("span",V,[t(f,{class:"me-2"}),c(" Code ")])])]),e("div",Y,[e("div",E,[G,e("div",W,[e("div",T,[t(x,{class:"text-white-dark"})]),q])]),e("div",null,[H,e("div",J,[K,e("div",O,[t(x,{class:"text-white-dark"})])])])]),r(s).includes("code2")?(n(),b(a,{key:0},{default:o(()=>[Q]),_:1})):u("",!0)]),e("div",X,[e("div",Z,[ee,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:d[2]||(d[2]=l=>r(i)("code3"))},[e("span",re,[t(f,{class:"me-2"}),c(" Code ")])])]),e("div",te,[e("div",de,[oe,e("div",le,[e("div",ne,[t(k,{class:"text-white-dark animate-spin"})]),se])]),e("div",null,[ie,e("div",ae,[ce,e("div",be,[t(k,{class:"text-white-dark animate-spin"})])])])]),r(s).includes("code3")?(n(),b(a,{key:0},{default:o(()=>[ue]),_:1})):u("",!0)]),e("div",fe,[e("div",pe,[me,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:d[3]||(d[3]=l=>r(i)("code4"))},[e("span",he,[t(f,{class:"me-2"}),c(" Code ")])])]),e("div",ve,[e("div",xe,[ge,e("div",_e,[t(h,{placement:r(m).rtlClass==="rtl"?"bottom-end":"bottom-start",offsetDistance:"0",class:"align-middle input-group-dropodwn"},{content:o(({close:l})=>[e("ul",{onClick:v=>l()},Re,8,ye)]),default:o(()=>[e("div",ke,[t(g,{class:"w-5 h-5 text-white"})])]),_:1},8,["placement"]),Se])]),e("div",Ae,[Be,e("div",$e,[De,t(h,{placement:r(m).rtlClass==="rtl"?"bottom-start":"bottom-end",offsetDistance:"0",class:"align-middle input-group-dropodwn"},{content:o(({close:l})=>[e("ul",{onClick:v=>l()},Me,8,Ne)]),default:o(()=>[e("div",Pe,[t(g,{class:"w-5 h-5 text-white"})])]),_:1},8,["placement"])])])]),r(s).includes("code4")?(n(),b(a,{key:0},{default:o(()=>[Ve]),_:1})):u("",!0)]),e("div",Ye,[e("div",Ee,[Ge,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:d[4]||(d[4]=l=>r(i)("code5"))},[e("span",We,[t(f,{class:"me-2"}),c(" Code ")])])]),Te,r(s).includes("code5")?(n(),b(a,{key:0},{default:o(()=>[qe]),_:1})):u("",!0)]),e("div",He,[e("div",Je,[Ke,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:d[5]||(d[5]=l=>r(i)("code6"))},[e("span",Oe,[t(f,{class:"me-2"}),c(" Code ")])])]),Qe,r(s).includes("code6")?(n(),b(a,{key:0},{default:o(()=>[Xe]),_:1})):u("",!0)]),e("div",Ze,[e("div",er,[rr,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:d[6]||(d[6]=l=>r(i)("code7"))},[e("span",tr,[t(f,{class:"me-2"}),c(" Code ")])])]),dr,r(s).includes("code7")?(n(),b(a,{key:0},{default:o(()=>[or]),_:1})):u("",!0)])]),e("div",lr,[e("div",nr,[sr,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:d[7]||(d[7]=l=>r(i)("code8"))},[e("span",ir,[t(f,{class:"me-2"}),c(" Code ")])])]),ar,r(s).includes("code8")?(n(),b(a,{key:0},{default:o(()=>[cr]),_:1})):u("",!0)]),e("div",br,[e("div",ur,[e("div",fr,[pr,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:d[8]||(d[8]=l=>r(i)("code9"))},[e("span",mr,[t(f,{class:"me-2"}),c(" Code ")])])]),hr,r(s).includes("code9")?(n(),b(a,{key:0},{default:o(()=>[vr]),_:1})):u("",!0)]),e("div",xr,[e("div",gr,[_r,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:d[9]||(d[9]=l=>r(i)("code10"))},[e("span",kr,[t(f,{class:"me-2"}),c(" Code ")])])]),yr,r(s).includes("code10")?(n(),b(a,{key:0},{default:o(()=>[wr]),_:1})):u("",!0)])]),e("div",jr,[e("div",Cr,[e("div",Lr,[Rr,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:d[10]||(d[10]=l=>r(i)("code11"))},[e("span",Sr,[t(f,{class:"me-2"}),c(" Code ")])])]),e("div",Ar,[e("form",null,[e("div",Br,[$r,e("div",Dr,[t(h,{placement:r(m).rtlClass==="rtl"?"bottom-end":"bottom-start",offsetDistance:"0",class:"align-middle input-group-dropodwn"},{content:o(({close:l})=>[e("ul",{onClick:v=>l()},Mr,8,Nr)]),default:o(()=>[Pr]),_:1},8,["placement"]),Vr])]),e("div",Yr,[Er,e("div",Gr,[Wr,t(h,{placement:r(m).rtlClass==="rtl"?"bottom-start":"bottom-end",offsetDistance:"0",class:"align-middle input-group-dropodwn"},{content:o(({close:l})=>[e("ul",{onClick:v=>l()},Qr,8,qr)]),default:o(()=>[Tr]),_:1},8,["placement"])])])])]),r(s).includes("code11")?(n(),b(a,{key:0},{default:o(()=>[Xr]),_:1})):u("",!0)]),e("div",Zr,[e("div",et,[rt,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:d[11]||(d[11]=l=>r(i)("code12"))},[e("span",tt,[t(f,{class:"me-2"}),c(" Code ")])])]),e("div",dt,[e("form",null,[e("div",ot,[lt,e("div",nt,[st,t(h,{placement:r(m).rtlClass==="rtl"?"bottom-end":"bottom-start",offsetDistance:"0",class:"align-middle input-group-dropodwn"},{content:o(({close:l})=>[e("ul",{onClick:v=>l()},pt,8,at)]),default:o(()=>[e("div",it,[t(_,{class:"w-5 h-5"})])]),_:1},8,["placement"]),mt])]),e("div",ht,[vt,e("div",xt,[gt,t(h,{placement:r(m).rtlClass==="rtl"?"bottom-start":"bottom-end",offsetDistance:"0",class:"align-middle input-group-dropodwn"},{content:o(({close:l})=>[e("ul",{onClick:v=>l()},Lt,8,kt)]),default:o(()=>[e("div",_t,[t(_,{class:"w-5 h-5"})])]),_:1},8,["placement"]),Rt])])])]),r(s).includes("code12")?(n(),b(a,{key:0},{default:o(()=>[St]),_:1})):u("",!0)]),e("div",At,[e("div",Bt,[$t,e("a",{class:"font-semibold hover:text-gray-400 dark:text-gray-400 dark:hover:text-gray-600",href:"javascript:;",onClick:d[12]||(d[12]=l=>r(i)("code13"))},[e("span",Dt,[t(f,{class:"me-2"}),c(" Code ")])])]),Pt,r(s).includes("code13")?(n(),b(a,{key:0},{default:o(()=>[Nt]),_:1})):u("",!0)])])])])}}});export{Yt as default};
