const s="/assets/images/profile-4.jpeg";export{s as _};
