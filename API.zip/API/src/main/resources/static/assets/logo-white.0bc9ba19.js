const s="/assets/images/auth/logo-white.svg";export{s as _};
