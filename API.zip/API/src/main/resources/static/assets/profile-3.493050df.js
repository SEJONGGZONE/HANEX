const s="/assets/images/profile-1.jpeg",e="/assets/images/profile-2.jpeg",a="/assets/images/profile-3.jpeg";export{s as _,e as a,a as b};
