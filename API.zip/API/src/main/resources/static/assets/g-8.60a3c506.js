const s="/assets/images/g-8.png";export{s as _};
