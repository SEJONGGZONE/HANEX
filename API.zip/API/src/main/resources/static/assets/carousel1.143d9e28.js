const s="/assets/images/carousel1.jpeg";export{s as _};
