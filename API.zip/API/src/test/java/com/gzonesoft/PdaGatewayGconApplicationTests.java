package com.gzonesoft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdaGatewayGconApplicationTests {

	@Test
	void contextLoads() {
	}

}
